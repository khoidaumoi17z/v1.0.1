# DangKhoi Tool 1.0 — nâng cấp phân tích CFG

Giữ tên DangKhoi Tool, version 1.0; tăng build lên 2. Giữ giao diện mint, icon và nhạc tự động, patch nhiều offset và giới hạn 100 MiB. Bản này bổ sung cfg.js, không nhúng IDA/Hex-Rays và không yêu cầu IDA để chạy app.

## Các phần học từ quy trình IDA và đã triển khai

1. Dựng khối lệnh và cạnh successor/predecessor từ B, B.cond, CBZ/CBNZ, TBZ/TBNZ, RET. Tính reachability từ mốc đầu hàm metadata. UDF, BR/điều khiển chưa giải được và cạnh ngoài phạm vi không nhận diện làm giảm độ đầy đủ của mô hình.
2. Theo dõi nguồn kết quả BL tới import/symbol qua MOV và các khối lệnh. Tại điểm hợp nhánh, chỉ giữ nguồn khi mọi predecessor reachable được mô hình hóa cùng cho một nguồn. Nếu một nhánh ghi đè/không có nguồn, xóa liên hệ. Cờ điều kiện NZCV tách khỏi thanh ghi XZR.
3. Dùng worklist tới khi trạng thái hội tụ; tuổi giá trị tối đa 64 lệnh. Vòng lặp kéo dài hoặc ngân sách vượt giới hạn không tự sinh liên hệ đã xác minh. Chưa theo dõi kết quả BLR qua nhiều khối; phần BLR cục bộ từ bản trước vẫn giữ.
4. Ghi các liên hệ call → condition, source block, condition block, số predecessor và khoảng theo dõi. Phát hiện hình dạng một nhánh thoát sớm, nhánh kia tiếp tục; đây là cấu trúc thường gặp, không phải bằng chứng riêng về antiban.
5. Có thể loại lời gọi/XREF/điều kiện ở vị trí không reachable trong mô hình đủ điều kiện. Nếu có bảng ngoại lệ __gcc_except_tab thì không loại chúng, vì chưa mô hình hóa cạnh ngoại lệ. Luồng dữ liệu lúc đó ghi normal-flow-only và không mang nhãn cfgVerified.
6. Giữ mẫu byte, chuỗi, import, XREF, dump C, quy tắc giảm ưu tiên, mở rộng một bước và đối chiếu phiên bản. Mẫu prologue không tự trở thành mục tiêu bảo mật.

## Điểm bổ sung

- Liên hệ nguồn kết quả → điều kiện trên CFG không có cảnh báo ngoại lệ: +6.
- Hình dạng thoát sớm/tiếp tục đi kèm liên hệ đó: +4.
- Khi có bảng ngoại lệ nhưng chỉ mô hình hóa luồng thường: hai thành phần trên giảm còn +2 và +2. Chưa khẳng định nguồn trên các cạnh ngoại lệ.
- Vẫn áp dụng mọi giới hạn điểm cũ: API chung, tiện ích, vòng đời, thiếu cấu trúc và địa chỉ mâu thuẫn. Ngưỡng thăm dò 35/chặt 55 không thay đổi. Điểm không phải phần trăm xác suất.

## Kết quả trên anogs người dùng đã cung cấp

SHA-256: `10b4b69f345ab9aee94f2861f73f674060084830f1c81d151e26fd6edee5d8f6`

| Chỉ tiêu | Trước CFG | Sau CFG |
|---|---:|---:|
| Mốc hàm | 13323 | 13323 |
| Đầu mối ≥35 | 28 | 28 |
| Đầu mối ≥55 | 2 | 2 |

Đã dựng CFG cho 13318 khoảng hàm, 84336 khối; 11926 khoảng hàm đủ các cạnh trực tiếp mà bộ giải mã hỗ trợ. Nhận 2375 mẫu dùng kết quả trong điều kiện trên CFG, trong đó 54 qua nhiều khối. Đây không phải 54 offset antiban mới: nhiều liên hệ không có bằng chứng bảo mật hoặc thuộc hàm đã có trong danh sách.

5332 vị trí thanh ghi/cờ tại điểm hợp nhánh có nguồn không đồng nhất được bỏ khỏi liên hệ. 5 khoảng hàm vượt điều kiện kích thước/căn chỉnh không được dựng CFG. Không chạm ngân sách tổng hoặc giới hạn hội tụ trong file mẫu.

File có __gcc_except_tab nên bộ phân tích đánh dấu normal-flow-only, không xóa dấu hiệu ở vùng chưa reachable trong mô hình. 67480 lệnh được đếm là chưa reachable theo cạnh thường, không kết luận đó là mã chết trong thực tế.

Số đầu mối giữ nguyên; bằng chứng/giải thích của một số hàm chi tiết hơn. Chưa có tập hàm được gán nhãn hoặc kiểm chứng game runtime để đo precision/recall, vì vậy không tuyên bố đã tăng độ chính xác thực tế hoặc hiệu quả tránh ban.

## Cách dùng

Nạp Mach-O → chọn chế độ/giới hạn kết quả như trước → chọn một hàm. Phần chi tiết thêm số khối, reachability, độ đầy đủ, trạng thái hội tụ, các điểm hợp nhánh mơ hồ và thông tin call/condition theo khối. JSON hàm ưu tiên kèm cfg; chẩn đoán có binaryStats.cfg và analysisRevision. Nếu chỉ nạp dump C, không có CFG ARM64; giữ bộ đọc điều kiện C cũ.

## Giới hạn

Tối đa 8.192 lệnh/32 KiB cho mỗi khoảng hàm, 2.048 khối, 64 lệnh tuổi giá trị, 4.000.000 lượt xử lý lệnh, 20.000 liên hệ điều kiện. Mốc hàm vẫn theo metadata, chưa phục hồi đầy đủ function chunks/shared epilogue hoặc exception landing pad. Không có phân tích stack/memory alias, mọi phép biến đổi giá trị, phân giải jump table/luồng gián tiếp đầy đủ, runtime debugger hoặc quyết định ban ở máy chủ. Phân tích C và Mach-O chưa tự chứng minh cùng phiên bản.

## Tạo IPA

1. Upload **DangKhoi-Tool-iPhone-1.0-CFG.zip** vào gốc repository, giữ nguyên ZIP và tên.
2. Thay **.github/workflows/build-ipa.yml** bằng **DangKhoi-build-ipa-1.0-CFG.yml** đi kèm.
3. Mở **Actions → Build DangKhoi Tool 1.0 CFG → Run workflow**.
4. Tải artifact **DangKhoi-Tool-1.0-CFG-unsigned-IPA**, giải nén lấy IPA. Ký phù hợp trước khi cài.

Workflow kiểm thử Node, patch engine Swift, build Xcode và kiểm tra cfg.js/nhạc/icon/tên/version trong bundle. Chưa chạy Xcode hoặc iPhone thật trong môi trường này.

## Tài liệu chính thức đã tham khảo

- Khối và predecessor/successor: https://ida-domain.docs.hex-rays.com/ref/flowchart/
- Microcode và quan hệ use-def giữa khối: https://cpp.docs.hex-rays.com/vmpage.html
- API khối lệnh: https://python.docs.hex-rays.com/ida_gdl/index.html

Trong source chỉ triển khai thuật toán giới hạn riêng; không sử dụng microcode hoặc bộ decompiler của Hex-Rays.
