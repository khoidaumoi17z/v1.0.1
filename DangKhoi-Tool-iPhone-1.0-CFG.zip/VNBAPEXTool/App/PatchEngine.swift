import Foundation

struct DeskPatchEdit {
    let offset: UInt64
    let before: Data
    let after: Data
}

enum DeskPatchFailure: LocalizedError {
    case invalid(String)
    var errorDescription: String? { if case .invalid(let text) = self { return text }; return nil }
}

enum DeskPatchEngine {
    static let limit = 100 * 1024 * 1024
    static func bytes(_ text: String) throws -> Data {
        guard !text.isEmpty, text.count <= 512, text.count % 2 == 0,
              text.utf8.allSatisfy({ (48...57).contains($0) || (65...70).contains($0) || (97...102).contains($0) }) else {
            throw DeskPatchFailure.invalid("Byte hex không hợp lệ.")
        }
        var result = Data(), index = text.startIndex
        while index < text.endIndex {
            let end = text.index(index, offsetBy: 2)
            guard let byte = UInt8(text[index..<end], radix: 16) else { throw DeskPatchFailure.invalid("Byte hex không hợp lệ.") }
            result.append(byte); index = end
        }
        return result
    }
    static func hex(_ bytes: Data) -> String { bytes.map { String(format: "%02X", $0) }.joined() }
    static func size(_ input: URL) throws -> UInt64 {
        let values = try input.resourceValues(forKeys: [.isRegularFileKey, .fileSizeKey])
        guard values.isRegularFile == true, let size = values.fileSize, size > 0, size <= limit else {
            throw DeskPatchFailure.invalid("File cần là tệp thường, tối đa 100 MiB.")
        }
        return UInt64(size)
    }
    static func read(_ input: URL, offset: UInt64, count: Int) throws -> Data {
        let length = try size(input)
        guard count > 0, count <= 256, offset <= length, UInt64(count) <= length - offset else {
            throw DeskPatchFailure.invalid("Vị trí patch vượt file.")
        }
        let handle = try FileHandle(forReadingFrom: input)
        defer { try? handle.close() }
        try handle.seek(toOffset: offset)
        let bytes = try handle.read(upToCount: count) ?? Data()
        guard bytes.count == count else { throw DeskPatchFailure.invalid("Không đọc đủ byte gốc.") }
        return bytes
    }
    static func export(input: URL, output: URL, edits: [DeskPatchEdit]) throws {
        let length = try size(input)
        guard !edits.isEmpty, edits.count <= 1000, input.standardizedFileURL != output.standardizedFileURL else {
            throw DeskPatchFailure.invalid("Danh sách patch hoặc đường dẫn xuất không hợp lệ.")
        }
        let sorted = edits.sorted { $0.offset < $1.offset }
        var end: UInt64 = 0
        for edit in sorted {
            guard edit.offset >= end, edit.offset <= length, edit.after.count > 0, edit.after.count <= 256,
                  edit.before.count == edit.after.count, edit.before != edit.after,
                  UInt64(edit.after.count) <= length - edit.offset else {
                throw DeskPatchFailure.invalid("Patch chồng lấn, sai kích thước hoặc vượt file.")
            }
            end = edit.offset + UInt64(edit.after.count)
        }
        // Every export starts from the immutable imported snapshot, never the previous output.
        try FileManager.default.copyItem(at: input, to: output)
        var success = false
        defer { if !success { try? FileManager.default.removeItem(at: output) } }
        let handle = try FileHandle(forUpdating: output)
        defer { try? handle.close() }
        // Validate the entire plan before writing anything.
        for edit in sorted {
            try handle.seek(toOffset: edit.offset)
            let old = try handle.read(upToCount: edit.before.count) ?? Data()
            guard old == edit.before else { throw DeskPatchFailure.invalid("Byte gốc đã thay đổi tại 0x\(String(edit.offset, radix: 16)). Hãy đọc lại.") }
        }
        for edit in sorted {
            try handle.seek(toOffset: edit.offset)
            try handle.write(contentsOf: edit.after)
        }
        try handle.synchronize()
        for edit in sorted {
            try handle.seek(toOffset: edit.offset)
            let patched = try handle.read(upToCount: edit.after.count) ?? Data()
            guard patched == edit.after else { throw DeskPatchFailure.invalid("Kiểm tra byte sau ghi thất bại.") }
        }
        guard try size(output) == length else { throw DeskPatchFailure.invalid("Kích thước file sau patch bị thay đổi.") }
        success = true
    }
}
