/* Manual fixed-length patch plans. Address validation is separate from role assessment. */
(function(root){'use strict';
function hex(bytes){return Array.from(bytes,b=>b.toString(16).padStart(2,'0')).join('').toUpperCase();}
function parseBytes(text){const s=String(text).replace(/\s/g,'');if(!/^(?:[0-9a-f]{2}){1,256}$/i.test(s))throw Error('Nhập 1–256 byte hex, ví dụ C0035FD6.');return Uint8Array.from(s.match(/../g).map(x=>parseInt(x,16)));}
function number(text){if(!/^(?:0x)?[0-9a-f]{1,16}$/i.test(String(text).trim()))throw Error('Offset phải là hex, ví dụ 0x9FC8.');return BigInt('0x'+String(text).trim().replace(/^0x/i,''));}
function resolve(model,fileSize,kind,address,length){
 if(!model||model.encrypted)throw Error('Nạp Mach-O chưa mã hóa để patch.');
 if(!Number.isSafeInteger(fileSize)||fileSize<1||fileSize>104857600)throw Error('Kích thước file không hợp lệ.');
 if(!Number.isInteger(length)||length<1||length>256)throw Error('Độ dài patch không hợp lệ.');
 const value=number(address);let va,offset;
 if(kind==='file'){offset=value;for(const s of model.sections){const m=model.map(s.va);if(m&&offset>=m.fileOffset&&offset<m.fileOffset+s.size){va=s.va+offset-m.fileOffset;break;}}}
 else if(kind==='va'||kind==='rva'){va=kind==='rva'?model.base+value:value;offset=model.map(va)?.fileOffset;}
 else throw Error('Loại địa chỉ không hợp lệ.');
 if(va===undefined||offset===undefined||offset<0n||offset+BigInt(length)>BigInt(fileSize))throw Error('Patch nằm ngoài dữ liệu file được ánh xạ.');
 const section=model.codeSection(va),lastVA=va+BigInt(length)-1n,last=model.map(lastVA);
 if(!section||lastVA>=section.va+section.size||!last||last.fileOffset!==offset+BigInt(length)-1n)throw Error('Patch phải nằm trọn trong một section mã, không ghi header/data/stub.');
 if(va%4n||length%4)throw Error('Patch mã ARM64 cần địa chỉ căn 4 và độ dài là bội số 4 byte.');
 return {offset:Number(offset),va,rva:va-model.base,length,section:section.name};
}
function validate(plan,fileSize){if(!Array.isArray(plan)||!plan.length||plan.length>1000)throw Error('Chọn 1–1000 patch.');const sorted=plan.map(p=>{const before=parseBytes(p.before),after=parseBytes(p.after);if(!Number.isSafeInteger(p.offset)||p.offset<0||p.offset+after.length>fileSize||before.length!==after.length)throw Error('Patch sai kích thước hoặc vượt file.');if(hex(before)===hex(after))throw Error('Byte mới giống byte gốc.');return {...p,before:hex(before),after:hex(after),length:after.length};}).sort((a,b)=>a.offset-b.offset);for(let i=1;i<sorted.length;i++)if(sorted[i].offset<sorted[i-1].offset+sorted[i-1].length)throw Error('Các patch chồng lấn; xóa patch cũ trước.');return sorted;}
function apply(bytes,plan){const sorted=validate(plan,bytes.length);for(const p of sorted)if(hex(bytes.subarray(p.offset,p.offset+p.length))!==p.before)throw Error('Byte gốc đã thay đổi tại offset '+p.offset.toString(16));const out=Uint8Array.from(bytes);for(const p of sorted)out.set(parseBytes(p.after),p.offset);return out;}
const api={hex,parseBytes,number,resolve,validate,apply};root.OffsetPatch=api;if(typeof module!=='undefined')module.exports=api;
})(typeof globalThis==='undefined'?this:globalThis);
