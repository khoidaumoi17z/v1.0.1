/* Conservative, bounded ARM64 facts. Unknown instructions/control-flow kill state. */
(function(root){
'use strict';
function create(bytes,model){
 const functions=new Map(model.rows.map(r=>[r.va.toString(),r])),stubs=new Map(),pointers=new Map(),strings=new Map((model.stringFindings||[]).filter(s=>s.va!==null&&s.section!=='ngoài section đã biết').map(s=>[s.va.toString(),s]));
 for(const s of model.imports||[])(s.kind==='stub'?stubs:pointers).set(s.va.toString(),s);
 const refs=[],calls=[],checks=[],tails=[],seenRefs=new Set(),regs=Array(31).fill(null),stats={resolvedImportCalls:0,indirectImportCalls:0,trackedConditionChecks:0,trackedStringReferences:0,unknownInstructionBarriers:0,limitReached:false};
 const blockTargets=new Set();let barriersComplete=true;
 function signed(x,bits){return x&(2**(bits-1))?x-2**bits:x;}
 for(const section of model.sections||[]){if(!(section.name==='__text'||(section.flags&0x80000400)!==0)||(section.flags&255)===8||['__stubs','__auth_stubs','__stub_helper'].includes(section.name))continue;const start=model.map(section.va),end=model.map(section.va+section.size-1n);if(!start||!end||end.fileOffset!==start.fileOffset+section.size-1n)continue;const offset=Number(start.fileOffset),size=Number(section.size);if(offset<0||offset+size>bytes.length)continue;
  for(let p=0;p+4<=size;p+=4){const q=offset+p,w=(bytes[q]|bytes[q+1]<<8|bytes[q+2]<<16|bytes[q+3]<<24)>>>0;let delta=null;if(w>>>26===5)delta=signed(w&0x3ffffff,26)*4;else if(((w&0xff000010)>>>0)===0x54000000||((w&0x7e000000)>>>0)===0x34000000)delta=signed((w>>>5)&0x7ffff,19)*4;else if(((w&0x7e000000)>>>0)===0x36000000)delta=signed((w>>>5)&0x3fff,14)*4;if(delta!==null){if(blockTargets.size>=200000){barriersComplete=false;break;}blockTargets.add((section.va+BigInt(p+delta)).toString());}}
  if(!barriersComplete)break;
 }
 stats.blockTargetLimitReached=!barriersComplete;stats.blockTargets=blockTargets.size;
 let caller=null,flags=null,pc=0n,previousPC=null;
 function clear(){regs.fill(null);flags=null;}
 function get(reg){const v=regs[reg];return v&&pc>=v.origin&&pc-v.origin<=48n?v:null;}
 function set(reg,value){if(reg<31)regs[reg]=value;}
 function target(va){const s=stubs.get(va.toString());return s?{name:s.name,va,imported:true}:functions.has(va.toString())?{name:functions.get(va.toString()).name,va,imported:false}:null;}
 function ref(v,method){if(caller===null||v?.kind!=='address')return;const s=strings.get(v.value.toString());if(!s)return;const key=caller+':'+v.origin+':'+s.va;if(seenRefs.has(key))return;seenRefs.add(key);if(refs.length>=20000){stats.limitReached=true;return;}refs.push({callerVA:caller,siteVA:v.origin,endSite:pc,stringVA:s.va,stringFileOffset:s.fileOffset,text:s.name,evidence:s.evidence,method,note:'Địa chỉ được dựng trong cửa sổ tối đa 12 lệnh, không qua ranh giới điều khiển/lệnh chưa hỗ trợ; chưa chứng minh chức năng.'});}
 function load(address){const imp=pointers.get(address.toString());if(imp)return {kind:'function',name:imp.name,targetVA:imp.va,imported:true,origin:pc};
  // Only a raw on-disk pointer to an already recognized string is followed.
  const m=model.map(address),end=model.map(address+7n);if(!m||!end||end.fileOffset!==m.fileOffset+7n)return null;const off=Number(m.fileOffset);if(off<0||off+8>bytes.length)return null;
  let value=0n;for(let i=7;i>=0;i--)value=(value<<8n)|BigInt(bytes[off+i]);return strings.has(value.toString())?{kind:'address',value,origin:pc}:null;
 }
 function call(t,indirect=false,tail=false){const args=[0,1,2].map(i=>{const v=get(i);return v?.kind==='constant'?v.value:null;});clear();if(!t)return;
  const record={callerVA:caller,siteVA:pc,targetVA:t.va??t.targetVA,targetName:t.name,imported:!!t.imported,method:tail?'B import stub':indirect?'LDR import pointer + BLR':'BL import/symbol',arguments:args};
  if(t.imported){stats.resolvedImportCalls++;if(indirect)stats.indirectImportCalls++;}
  if(caller!==null&&(t.imported||root.OffsetEvidence.callEvidence(t.name).length||root.OffsetEvidence.textEvidence(t.name,'Tên hàm được gọi').length)){if(calls.length<100000)calls.push(record);else stats.limitReached=true;}
  if(!tail)set(0,{kind:'result',origin:pc,call:record,steps:[]});
 }
 function condition(v,method,branchTarget){if(caller===null||v?.kind!=='result'||pc<v.origin||pc-v.origin>48n||!model.codeSection?.(branchTarget))return;if(checks.length>=20000){stats.limitReached=true;return;}
  checks.push({...v.call,callerVA:caller,conditionSiteVA:pc,branchTargetVA:branchTarget,method:method+(v.steps.length?' qua '+v.steps.join(', '):''),note:'Liên hệ cú pháp thanh ghi trả về trong tối đa 12 lệnh; chưa phải CFG hoặc chứng minh vai trò bảo mật.'});
 }
 return {push(w,siteVA,callerVA){pc=siteVA;if(previousPC!==null&&pc!==previousPC+4n)clear();previousPC=pc;if(callerVA!==caller||blockTargets.has(pc.toString())){clear();caller=callerVA;}
  if(!barriersComplete){if(w>>>26===0x25)call(target(pc+BigInt(signed(w&0x3ffffff,26)*4)));clear();return;}
  if(w===0xd503201f)return;
  const rd=w&31,rn=(w>>>5)&31;
  if((w&0x1f000000)===0x10000000){let imm=signed((((w>>>5)&0x7ffff)*4)+((w>>>29)&3),21);const page=!!(w>>>31),value=page?(pc&~4095n)+BigInt(imm)*4096n:pc+BigInt(imm);const v={kind:'address',value,origin:pc};set(rd,v);if(!page)ref(v,'ADR');return;}
  if(((w&0xff800000)>>>0)===0x91000000){const src=get(rn),imm=BigInt((w>>>10)&4095)*((w>>>22)&1?4096n:1n);if(src?.kind==='address'){const v={...src,value:src.value+imm};set(rd,v);ref(v,pc-src.origin===4n?'ADRP + ADD kề nhau':'Dựng địa chỉ ARM64 qua thanh ghi');}else set(rd,null);return;}
  if(((w&0x7fe0ffe0)>>>0)===0x2a0003e0){const src=get((w>>>16)&31);if(src?.kind==='result')set(rd,{...src,steps:src.steps.concat('MOV').slice(-4)});else if(src?.kind==='address'&&(w>>>31))set(rd,{...src});else if(src?.kind==='constant')set(rd,{...src,value:w>>>31?src.value:BigInt.asUintN(32,src.value)});else set(rd,null);return;}
  const mov=w&0x7f800000;if(mov===0x52800000||mov===0x12800000||mov===0x72800000){const width=w>>>31?64:32,shift=BigInt((w>>>21)&3)*16n,n=BigInt((w>>>5)&0xffff)<<shift,old=get(rd);let value=mov===0x52800000?n:mov===0x12800000?BigInt.asUintN(width,~n):old?.kind==='constant'?(old.value&~(65535n<<shift))|n:null;set(rd,value===null?null:{kind:'constant',value:BigInt.asUintN(width,value),origin:pc});return;}
  if(((w&0xffc00000)>>>0)===0xf9400000){const src=get(rn),v=src?.kind==='address'?load(src.value+BigInt((w>>>10)&4095)*8n):null;set(rd,v);if(v?.kind==='address')ref(v,'LDR con trỏ tĩnh tới chuỗi');return;}
  if(((w&0xff000000)>>>0)===0x58000000){const v=load(pc+BigInt(signed((w>>>5)&0x7ffff,19)*4));set(rd,v);if(v?.kind==='address')ref(v,'LDR literal con trỏ tới chuỗi');return;}
  const ls=(w&0xffc00000)>>>0;if([0xb9400000,0x39400000,0x79400000].includes(ls)){set(rd,null);return;}if([0xf9000000,0xb9000000,0x39000000,0x79000000].includes(ls)){if(rn!==31)clear();return;}
  if((w>>>26)===0x25){const t=target(pc+BigInt(signed(w&0x3ffffff,26)*4));call(t);return;}
  if(((w&0xfffffc1f)>>>0)===0xd63f0000){const t=get(rn);call(t?.kind==='function'?t:null,true);return;}
  if((w>>>26)===5){const va=pc+BigInt(signed(w&0x3ffffff,26)*4),t=target(va);if(t?.imported)call(t,false,true);else if(t&&caller!==null&&va!==caller){if(tails.length<100000)tails.push({callerVA:caller,siteVA:pc,targetVA:va,source:'ARM64 B tới mốc hàm',note:'Nhánh tới mốc hàm khác; chưa xác minh tail-call.'});else stats.limitReached=true;}clear();return;}
  if(((w&0x7e000000)>>>0)===0x34000000||((w&0x7e000000)>>>0)===0x36000000){const bit=((w&0x7e000000)>>>0)===0x36000000;condition(get(rd),bit?'TBZ/TBNZ kết quả lời gọi':'CBZ/CBNZ kết quả lời gọi',pc+BigInt(signed((w>>>5)&(bit?0x3fff:0x7ffff),bit?14:19)*4));clear();return;}
  if(((w&0x7f00001f)>>>0)===0x7100001f||((w&0x7f00001f)>>>0)===0x3100001f){flags=get(rn);return;}
  if(((w&0xff000010)>>>0)===0x54000000){if((w&15)<14)condition(flags,'CMP/CMN + B.cond kết quả lời gọi',pc+BigInt(signed((w>>>5)&0x7ffff,19)*4));clear();return;}
  // Recognized arithmetic only writes Rd (and optionally flags).
  if([0x0b000000,0x1b000000,0x0a000000].includes(w&0x1f000000)){set(rd,null);if((w&0x1f000000)===0x0b000000&&(w&0x20000000))flags=null;if((w&0x1f000000)===0x0a000000&&((w>>>29)&3)===3)flags=null;return;}
  if(((w&0x1f000000)>>>0)===0x11000000){set(rd,null);if(w&0x20000000)flags=null;return;}
  clear();stats.unknownInstructionBarriers++;
 },finish(){stats.trackedConditionChecks=checks.length;stats.trackedStringReferences=refs.length;return {references:refs,calls,checks,tails,stats};}};
}
const api={create};root.OffsetMachine=api;if(typeof module!=='undefined')module.exports=api;
})(typeof globalThis==='undefined'?this:globalThis);
