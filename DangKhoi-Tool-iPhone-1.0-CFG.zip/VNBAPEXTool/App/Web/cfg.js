/* Bounded intraprocedural ARM64 CFG and must-agree return-value flow. No runtime verdict. */
(function(root){'use strict';
const MAX_WORDS=8192,MAX_BLOCKS=2048,MAX_AGE=64,MAX_WORK=4000000;
function signed(n,b){return n&(2**(b-1))?n-2**b:n;}
function control(w,i){
 if(w<=0xffff)return {kind:'unknown'}; // UDF immediate (including zero padding)
 if(w>>>26===5)return {kind:'jump',target:i+signed(w&0x3ffffff,26)};
 if(((w&0xff000000)>>>0)===0x54000000)return {kind:'conditional',target:i+signed((w>>>5)&0x7ffff,19),unknown:!!(w&16),method:'B.cond'};
 if(((w&0x7e000000)>>>0)===0x34000000)return {kind:'conditional',target:i+signed((w>>>5)&0x7ffff,19),method:'CBZ/CBNZ'};
 if(((w&0x7e000000)>>>0)===0x36000000)return {kind:'conditional',target:i+signed((w>>>5)&0x3fff,14),method:'TBZ/TBNZ'};
 if(((w&0xfffffc1f)>>>0)===0xd65f0000)return {kind:'return'};
 if(((w&0xfffffc1f)>>>0)===0xd63f0000)return null; // ordinary BLR returns locally
 if(((w&0xfe000000)>>>0)===0xd6000000||((w&0xff000000)>>>0)===0xd4000000)return {kind:'unknown'};
 return null;
}
function build(words){
 const leaders=new Set([0]),controls=new Map();let unknown=0;
 for(let i=0;i<words.length;i++){const c=control(words[i],i);if(!c)continue;controls.set(i,c);if(c.kind==='unknown'||c.unknown)unknown++;if(c.target!==undefined&&c.target>=0&&c.target<words.length)leaders.add(c.target);if(i+1<words.length)leaders.add(i+1);}
 if(leaders.size>MAX_BLOCKS)return null;
 const starts=[...leaders].sort((a,b)=>a-b),blocks=starts.map((start,id)=>({id,start,end:starts[id+1]??words.length,successors:[],predecessors:[],reachable:false,control:null})),owner=new Int32Array(words.length);
 for(const b of blocks)owner.fill(b.id,b.start,b.end);
 for(const b of blocks){const c=controls.get(b.end-1);b.control=c||null;const next=b.id+1<blocks.length?b.id+1:null;
  function edge(id){if(id!==null&&!b.successors.includes(id)){b.successors.push(id);blocks[id].predecessors.push(b.id);}}
  if(!c)edge(next);else if(c.kind==='conditional'){edge(next);if(c.target>=0&&c.target<words.length)edge(owner[c.target]);else unknown++;}else if(c.kind==='jump'){if(c.target>=0&&c.target<words.length)edge(owner[c.target]);}
 }
 const queue=[0];blocks[0].reachable=true;for(let q=0;q<queue.length;q++)for(const s of blocks[queue[q]].successors)if(!blocks[s].reachable){blocks[s].reachable=true;queue.push(s);}
 unknown=blocks.reduce((n,b)=>{if(!b.reachable)return n;const c=b.control;return n+(c&&(c.kind==='unknown'||c.unknown)?1:0)+(c?.kind==='conditional'&&(c.target<0||c.target>=words.length)?1:0);},0);
 return {blocks,owner,unknown};
}
function analyze(bytes,model){
 const facts={checks:[],functions:[],stats:{functions:0,completeFunctions:0,blocks:0,reachableInstructions:0,unreachableInstructions:0,unknownControlFunctions:0,oversizedFunctions:0,workLimitReached:false,flowLimitedFunctions:0,flowChecks:0,crossBlockChecks:0,ambiguousJoins:0,work:0}},starts=new Map(model.rows.map(r=>[r.va.toString(),r])),imports=new Map((model.imports||[]).filter(i=>i.kind==='stub').map(i=>[i.va.toString(),i]));
 if(model.encrypted){facts.stats.skipped='Encrypted code';return facts;}
 const exceptionTables=model.sections.some(s=>s.name==='__gcc_except_tab'&&s.size>0n);facts.stats.exceptionEdgesNotModeled=exceptionTables;
 let checksLimited=false;
 for(const section of model.sections){if(!model.codeSection(section.va)||!section.size)continue;const range=model.map(section.va),endMap=model.map(section.va+section.size-1n);if(!range||!endMap||endMap.fileOffset!==range.fileOffset+section.size-1n)continue;
  const rows=model.rows.filter(r=>r.va>=section.va&&r.va<section.va+section.size).sort((a,b)=>a.va<b.va?-1:1);
  for(let ri=0;ri<rows.length;ri++){
   const row=rows[ri],end=rows[ri+1]?.va??section.va+section.size,span=end-row.va,count=Number(span/4n);if(row.va%4n||span%4n||count<1||count>MAX_WORDS){facts.stats.oversizedFunctions++;continue;}
   if(facts.stats.work>=MAX_WORK){facts.stats.workLimitReached=true;break;}
   const map=model.map(row.va),offset=Number(map?.fileOffset);if(!map||offset<0||offset+count*4>bytes.length)continue;
   const words=new Uint32Array(count);for(let i=0;i<count;i++){const p=offset+4*i;words[i]=(bytes[p]|bytes[p+1]<<8|bytes[p+2]<<16|bytes[p+3]<<24)>>>0;}
   const graph=build(words);if(!graph){facts.stats.oversizedFunctions++;continue;}const {blocks,owner}=graph;
   // An external direct jump is only a recognized exit if it names a known function/import.
   for(const b of blocks){const c=b.control;if(b.reachable&&c?.kind==='jump'&&(c.target<0||c.target>=count)){const va=row.va+BigInt(c.target*4);if(!starts.has(va.toString())&&!imports.has(va.toString()))graph.unknown++;}}
   if(blocks.at(-1)?.reachable&&!blocks.at(-1).control)graph.unknown++;
   const complete=graph.unknown===0,ranges=[],summary={va:row.va,endVA:end,blocks:blocks.length,reachableBlocks:blocks.filter(b=>b.reachable).length,complete,pruningSafe:complete&&!exceptionTables,exceptionEdgesNotModeled:exceptionTables,flowComplete:false,unknownControl:graph.unknown,reachableInstructions:0,unreachableInstructions:0,checks:0,crossBlockChecks:0,ambiguousJoins:0,guardShapes:0,witnesses:[],unreachableRanges:ranges};
   for(const b of blocks){if(b.reachable)summary.reachableInstructions+=b.end-b.start;else{summary.unreachableInstructions+=b.end-b.start;ranges.push({startVA:row.va+BigInt(b.start*4),endVA:row.va+BigInt(b.end*4)});}}
   facts.stats.functions++;facts.stats.blocks+=blocks.length;facts.stats.reachableInstructions+=summary.reachableInstructions;facts.stats.unreachableInstructions+=summary.unreachableInstructions;if(complete)facts.stats.completeFunctions++;else facts.stats.unknownControlFunctions++;
   function target(i,w){const va=row.va+BigInt((i+signed(w&0x3ffffff,26))*4),name=imports.get(va.toString())?.name||starts.get(va.toString())?.name;if(!name)return null;return {callerVA:row.va,siteVA:row.va+BigInt(i*4),targetVA:va,targetName:name,imported:imports.has(va.toString()),originBlock:owner[i]};}
   const calls=new Map();for(let i=0;i<count;i++)if(words[i]>>>26===0x25){const t=target(i,words[i]);if(t)calls.set(i,t);}
   const empty=()=>Array(32).fill(null),outputs=Array(blocks.length).fill(null),inputs=Array(blocks.length).fill(null);
   const eq=(a,b)=>a?.id===b?.id&&a?.age===b?.age;
   const same=(a,b)=>!!a&&!!b&&a.every((v,i)=>eq(v,b[i]));
   function meet(b){if(b.id===0)return empty();const preds=b.predecessors.filter(p=>blocks[p].reachable);if(!preds.length)return empty();const state=empty();for(let i=0;i<32;i++){const values=preds.map(p=>outputs[p]?.[i]||null),first=values[0];if(first&&values.every(v=>v?.id===first.id))state[i]={id:first.id,age:Math.max(...values.map(v=>v.age))};}return state;}
   function transfer(b,input,emit=false){let state=input.map(v=>v?{...v}:null);const kill=()=>state.fill(null);const get=r=>r<31?state[r]:null,set=(r,v)=>{if(r<31)state[r]=v;};
    for(let i=b.start;i<b.end;i++){
     facts.stats.work++;if(facts.stats.work>MAX_WORK)return null;
     for(let r=0;r<32;r++)if(state[r]){state[r]={...state[r],age:state[r].age+1};if(state[r].age>MAX_AGE)state[r]=null;}
     const w=words[i],rd=w&31,rn=(w>>>5)&31,c=control(w,i);
     if(c){if(c.kind==='conditional'&&emit){let value=c.method==='B.cond'?state[31]:get(rd);if(c.method==='B.cond'&&(w&15)>=14)value=null;const t=value?calls.get(value.id):null;if(t&&c.target>=0&&c.target<count){const cross=t.originBlock!==b.id,guard=guardShape(b);if(facts.checks.length<20000){facts.checks.push({...t,conditionSiteVA:row.va+BigInt(i*4),branchTargetVA:row.va+BigInt(c.target*4),method:'CFG '+c.method+(cross?' qua nhiều khối':' trong khối'),cfgVerified:!exceptionTables,cfgModeled:true,sourceBlock:t.originBlock,conditionBlock:b.id,predecessorCount:b.predecessors.filter(p=>blocks[p].reachable).length,cfgMode:exceptionTables?'normal-flow-only':'direct-flow',crossBlock:cross,flowDistance:value.age,guardShape:guard,note:'Nguồn giá trị đồng nhất trên predecessor được mô hình hóa, tối đa 64 lệnh; ranh giới theo metadata. '+(exceptionTables?'Chưa mô hình hóa cạnh ngoại lệ; chỉ xét luồng thông thường. ':'')+'Không xác nhận antiban.'});summary.checks++;if(cross)summary.crossBlockChecks++;if(guard)summary.guardShapes++;if(summary.witnesses.length<8)summary.witnesses.push({callVA:t.siteVA,conditionVA:row.va+BigInt(i*4),targetName:t.targetName,sourceBlock:t.originBlock,conditionBlock:b.id,crossBlock:cross,guardShape:guard});}else checksLimited=true;}}
      if(c.kind==='unknown')kill();continue;
     }
     if(w>>>26===0x25){kill();if(calls.has(i))set(0,{id:i,age:0});continue;}
     if(((w&0xfffffc1f)>>>0)===0xd63f0000){kill();continue;}
     if(w===0xd503201f)continue;
     if(((w&0x7fe0ffe0)>>>0)===0x2a0003e0){const v=get((w>>>16)&31);set(rd,v?{...v}:null);continue;}
     if(((w&0x7f00001f)>>>0)===0x7100001f||((w&0x7f00001f)>>>0)===0x3100001f){state[31]=get(rn)?{...get(rn)}:null;continue;}
     if((w&0x1f000000)===0x10000000||[0x52800000,0x12800000,0x72800000].includes(w&0x7f800000)){set(rd,null);continue;}
     const ls=(w&0xffc00000)>>>0;if([0xf9400000,0xb9400000,0x39400000,0x79400000].includes(ls)||((w&0xff000000)>>>0)===0x58000000){set(rd,null);continue;}
     if([0xf9000000,0xb9000000,0x39000000,0x79000000].includes(ls)){if(rn!==31)kill();continue;}
     if([0x0b000000,0x1b000000,0x0a000000].includes(w&0x1f000000)){set(rd,null);if(((w&0x1f000000)===0x0b000000&&(w&0x20000000))||((w&0x1f000000)===0x0a000000&&((w>>>29)&3)===3))state[31]=null;continue;}
     if((w&0x1f000000)===0x11000000){set(rd,null);if(w&0x20000000)state[31]=null;continue;}
     // SP-relative pair loads/stores: writes to loaded registers are unknown.
     if(((w&0x3a000000)>>>0)===0x28000000&&rn===31){if(w&0x00400000){set(rd,null);set((w>>>10)&31,null);}continue;}
     kill();
    }return state;
   }
   function guardShape(b){if(b.successors.length!==2)return false;function early(id){const seen=new Set();for(let n=0;n<4;n++){if(seen.has(id))return false;seen.add(id);const block=blocks[id];if(block.end-block.start>12)return false;for(let j=block.start;j<block.end;j++)if(words[j]>>>26===0x25||((words[j]&0xfffffc1f)>>>0)===0xd63f0000)return false;if(block.control?.kind==='return')return true;if(block.successors.length!==1)return false;id=block.successors[0];}return false;}return early(b.successors[0])!==early(b.successors[1]);}
   if(complete){const queue=blocks.filter(b=>b.reachable).map(b=>b.id),queued=new Set(queue);let cursor=0,steps=0,limited=false;
    while(cursor<queue.length){if(++steps>Math.min(10000,blocks.length*80)||facts.stats.work>MAX_WORK){limited=true;break;}const id=queue[cursor++];queued.delete(id);const b=blocks[id],input=meet(b);inputs[id]=input;const out=transfer(b,input);if(!out){limited=true;break;}if(!same(outputs[id],out)){outputs[id]=out;for(const s of b.successors)if(blocks[s].reachable&&!queued.has(s)){queued.add(s);queue.push(s);}}}
    if(!limited){const initialChecks=facts.checks.length;for(const b of blocks)if(b.reachable){if(b.predecessors.length>1){const preds=b.predecessors.filter(p=>blocks[p].reachable);for(let r=0;r<32;r++){const values=preds.map(p=>outputs[p]?.[r]||null);if(values.some(Boolean)&&(!values[0]||!values.every(v=>v?.id===values[0].id)))summary.ambiguousJoins++;}}if(!transfer(b,meet(b),true)){limited=true;break;}}
     if(limited){facts.checks.splice(initialChecks);summary.checks=summary.crossBlockChecks=summary.guardShapes=0;summary.witnesses=[];}
    }
    summary.flowComplete=!limited;if(limited)facts.stats.flowLimitedFunctions++;
   }
   facts.stats.ambiguousJoins+=summary.ambiguousJoins;facts.functions.push(summary);
  }
  if(facts.stats.workLimitReached||facts.stats.work>MAX_WORK){facts.stats.workLimitReached=true;break;}
 }
 facts.stats.flowChecks=facts.checks.length;facts.stats.crossBlockChecks=facts.checks.filter(c=>c.crossBlock).length;facts.stats.checkLimitReached=checksLimited;return facts;
}
const cache=new WeakMap();
function forRow(row,model){const cfg=model?.cfg;if(!cfg)return null;let index=cache.get(cfg);if(!index){index=new Map(cfg.functions.map(f=>[f.va.toString(),f]));cache.set(cfg,index);}return index.get(row.va.toString())||null;}
function reachable(row,site,model){const f=forRow(row,model);if(!f?.pruningSafe||site===null||site===undefined)return null;if(site<f.va||site>=f.endVA)return null;return !f.unreachableRanges.some(r=>site>=r.startVA&&site<r.endVA);}
const api={analyze,build,forRow,reachable,limits:{functionWords:MAX_WORDS,blocks:MAX_BLOCKS,valueAge:MAX_AGE,work:MAX_WORK}};root.OffsetCFG=api;if(typeof module!=='undefined')module.exports=api;
})(typeof globalThis==='undefined'?this:globalThis);
