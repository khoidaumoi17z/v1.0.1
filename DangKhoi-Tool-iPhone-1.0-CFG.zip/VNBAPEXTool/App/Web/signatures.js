/* Exact user-provided ARM64 prologues; matching does not establish function role. */
(function(root){'use strict';
const patterns=['FFC302D1F85F07A9F65708A9','FF4301D1F44F03A9FD7B04A9','FFC300D1F44F01A9FD7B02A9','FF4301D1F65702A9F44F03A9','FF8304D1FC6F0CA9FA670DA9','FF4302D1FC6F03A9FA6704A9','FFC301D1F65704A9F44F05A9','F85FBCA9F65701A9F44F02A9','FF0307D1FC6F1AA9FD7B1BA9'];
const compiled=patterns.map((hex,i)=>({id:'P'+(i+1),hex,bytes:Uint8Array.from(hex.match(/../g).map(x=>parseInt(x,16)))}));
function scan(bytes,model){
 const hits=[],stats={total:0,atFunctionStart:0,insideFunction:0,unowned:0,limitReached:false,skipped:model.encrypted?'Encrypted code':'',patterns:patterns.length};
 if(model.encrypted)return {hits,stats};
 const heads=new Map(model.rows.map(r=>[r.va.toString(),r]));
 for(const s of model.sections){if(!model.codeSection(s.va)||(s.flags&255)===8||['__stubs','__auth_stubs','__stub_helper'].includes(s.name))continue;
  const first=model.map(s.va),last=s.size?model.map(s.va+s.size-1n):null;if(!first||!last||last.fileOffset!==first.fileOffset+s.size-1n)continue;
  const off=Number(first.fileOffset),size=Number(s.size);if(off<0||off+size>bytes.length)continue;
  const rows=model.rows.filter(r=>r.va>=s.va&&r.va<s.va+s.size).sort((a,b)=>a.va<b.va?-1:1);let cursor=-1;
  for(let p=Number((4n-s.va%4n)%4n);p+12<=size;p+=4){const va=s.va+BigInt(p);while(cursor+1<rows.length&&rows[cursor+1].va<=va)cursor++;
   for(const pattern of compiled){if(bytes[off+p]!==pattern.bytes[0])continue;let equal=true;for(let j=1;j<12;j++)if(bytes[off+p+j]!==pattern.bytes[j]){equal=false;break;}if(!equal)continue;
    const head=heads.get(va.toString()),owner=head||(cursor>=0?rows[cursor]:null);stats.total++;if(head)stats.atFunctionStart++;else if(owner)stats.insideFunction++;else stats.unowned++;
    if(hits.length>=20000){stats.limitReached=true;continue;}
    hits.push({pattern:pattern.id,hex:pattern.hex,va,rva:va-model.base,fileOffset:first.fileOffset+BigInt(p),functionVA:owner?.va??null,functionName:owner?.name||null,atFunctionStart:!!head,section:s.name,verifiedRuntime:false,notice:head?'Exact prologue at metadata function start; role unverified.':'Exact aligned code match; function start unverified.'});
   }
  }
 }
 return {hits,stats};
}
const cache=new WeakMap();
function forRow(row,model){const scan=model?.signatureScan;if(!scan)return [];let index=cache.get(scan);if(!index){index=new Map();for(const h of scan.hits){if(h.functionVA===null)continue;const k=h.functionVA.toString();if(!index.has(k))index.set(k,[]);index.get(k).push(h);}cache.set(scan,index);}return index.get(row.va.toString())||[];}
const api={patterns,scan,forRow};root.OffsetSignatures=api;if(typeof module!=='undefined')module.exports=api;
})(typeof globalThis==='undefined'?this:globalThis);
