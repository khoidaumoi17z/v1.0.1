/* Bounded, read-only prioritization. Scores are ordinal weights, not probabilities. */
(function(root){
'use strict';
const E=root.OffsetEvidence;
function specific(text){const s=String(text).replace(/_/g,' ').replace(/([a-z0-9])([A-Z])/g,'$1 $2');return /\b(?:(?:check|detect|verify|is)\s*(?:hook|root|emulator|jailbreak|debugger|(?:code\s*)?signature|integrity)|(?:anti\s*cheat|anti\s*tamper|anti\s*debug)|(?:hook|root|emulator|debugger)\s*(?:detect(?:ion)?|check|attached)|jailbreak(?:en)?|jailbroken|(?:cheat|hack|security)\s*report|certificate\s*pinning|attestation)\b/i.test(s);}
// Only direct calls and straight-line local assignments are retained. No CFG claim.
function flow(){
 let token='',last='',statement='',condition=null,nesting=0,line=1,truncated=false,conditions=0,branches=0;
 const assignments=new Map(),checks=[],shape=root.OffsetFingerprint?.sketch('c-token4');
 function add(call,kind,variable){if(!specific(call)&&!E.callEvidence(call).length&&!/^(?:sub_|FUN_)[0-9a-f]+$/i.test(call))return;if(checks.some(x=>x.call===call&&x.kind===kind))return;if(checks.length<32)checks.push({call,kind,variable:variable||null,line});else {truncated=true;if(specific(call)){const weak=checks.findIndex(c=>!specific(c.call));if(weak>=0)checks[weak]={call,kind,variable:variable||null,line};}}}
 function word(){if(token){shape?.push(root.OffsetFingerprint.normalize(token));if(condition===null&&/(?:\+\+|--)\s*[A-Za-z_$][\w$]*$/.test(statement))assignments.delete(token);last=token;token='';}}
 function finishCondition(){
  if(/(?:^|[^=!<>])=(?!=)|\+\+|--/.test(condition)){assignments.clear();return;}
  if(/\bsizeof\s*\(|^\s*\(*\s*(?:0|false)\s*&&|^\s*\(*\s*(?:1|true)\s*\|\|/.test(condition))return;
  if(condition.length>2048){truncated=true;return;}
  for(const m of condition.matchAll(/\b([A-Za-z_$][\w$]*)\s*\(/g))if(!['sizeof','if','while','for','switch'].includes(m[1]))add(m[1],'direct-condition');
  for(const m of condition.matchAll(/\b[A-Za-z_$][\w$]*\b/g))if(assignments.has(m[0]))add(assignments.get(m[0]),'local-assignment-condition',m[0]);
 }
 return {push(c){
  if(c==='\n')line++;
  if(condition!==null){if(condition.length<=2048)condition+=c;if(c==='(')nesting++;if(c===')'&&--nesting===0){finishCondition();condition=null;}}
  if(/[A-Za-z0-9_$]/.test(c)){token+=c;if(token.length>256)token=token.slice(-256);}
  else {word();if(!/\s/.test(c))shape?.push(c);if(c==='('&&['if','while','switch'].includes(last)&&condition===null){condition='';nesting=1;conditions++;}if(!/\s/.test(c))last='';}
  if(c==='{'||c==='}'){assignments.clear();statement='';}
  else if(c===';'){
   const m=/^\s*(?:(?:unsigned|signed|const|int|bool|char|long|short|uint\d+_t|int\d+_t|_DWORD|_QWORD|_BOOL\d*|__int(?:8|16|32|64|128)|size_t|intptr_t|uintptr_t)\s+)*([A-Za-z_$][\w$]*)\s*=\s*(?:\([A-Za-z_][\w\s*]*\)\s*)*([A-Za-z_$][\w$]*)\s*\([^;]*\)\s*$/.exec(statement);
   if(m&&assignments.size<64)assignments.set(m[1],m[2]);else if(statement.includes('('))assignments.clear();statement='';
  }else {
   statement+=c;if(statement.length>2048)statement=statement.slice(-1024);
   // Invalidate a previous value at a write; captured assignment is installed at ';'.
   if(condition===null&&(c==='='||c==='+'||c==='-')){const m=/\b([A-Za-z_$][\w$]*)\s*(?:[+\-]|(?:[+\-*/%&|^]|<<|>>)?=)$/.exec(statement);if(m)assignments.delete(m[1]);}
  }
  if(last==='return'&&/\s/.test(c)){branches++;last='';}
 },finish(){word();return {fingerprint:shape?.finish()||null,checks,conditions,returns:branches,truncated,notice:'Syntactic C conditions and bounded straight-line local def-use; no full CFG or data-flow verification.'};}};
}
function rankDirect(rows,model){
 const rowsByName=new Map(rows.map(r=>[r.name,r])),metadataAddresses=new Set((model?.rows||[]).map(r=>r.va.toString())),index=new Map(rows.map(r=>[r.va.toString(),r])),edges=root.OffsetRelations.combine(rows,model).edges,callees=new Map(),binaryChecks=new Map();
 for(const c of model?.callGraph?.checks||[]){if(c.callerVA===null||!specific(c.targetName))continue;const key=c.callerVA.toString();if(!binaryChecks.has(key))binaryChecks.set(key,[]);if(binaryChecks.get(key).length<32)binaryChecks.get(key).push(c);}
 for(const e of edges){if(e.callerVA===null||!specific(index.get(e.targetVA.toString())?.name))continue;const key=e.callerVA.toString();if(!callees.has(key))callees.set(key,new Set());if(callees.get(key).size<64)callees.get(key).add(e.targetVA.toString());}
 const results=[];
 for(let i=0;i<rows.length;i++){
  const row=rows[i],machine=root.OffsetAssessment.machineFacts(row,model),evidence=E.unique([...E.forRow(row),...machine.evidence,...root.OffsetAssessment.referenceEvidence(row,model)]);
  const substantive=evidence.filter(e=>!['sdk','relation','xref'].includes(e.group)),groups=[...new Set(substantive.map(e=>e.group))];
  const name=evidence.some(e=>e.kind==='keyword'&&/Tên hàm/.test(e.where)&&specific(e.excerpt));
  const strings=evidence.filter(e=>e.kind==='keyword'&&!/Tên hàm|Tên lời gọi/.test(e.where)),context=strings.some(e=>specific(e.excerpt));
  const calls=(row.calls||[]).filter(specific),control=(row.controlFlow?.checks||[]).filter(c=>specific(c.call));
  const nativeControl=binaryChecks.get(row.va.toString())||[];
  const genericControl=(row.controlFlow?.checks||[]).filter(c=>E.callEvidence(c.call).length);
  const xref=evidence.some(e=>e.kind==='string-ref');
  const peer=[...(callees.get(row.va.toString())||[])].map(k=>index.get(k)).filter(r=>r&&specific(r.name));
  const conditionPeer=(row.controlFlow?.checks||[]).filter(c=>{const m=/^(?:sub_|FUN_)([0-9a-f]+)$/i.exec(c.call);const target=m?index.get(BigInt('0x'+m[1]).toString()):rowsByName.get(c.call);return target&&specific(target.name);});
  if(!evidence.length&&!control.length&&!conditionPeer.length&&!peer.length&&!nativeControl.length)continue;
  const inspect=c=>!specific(c.targetName)&&E.callEvidence(c.targetName).some(e=>['debug','memory','environment','signature'].includes(e.group));
  const inspectionCalls=machine.calls.filter(inspect),inspectionChecks=machine.checks.filter(inspect),apiNames=new Set(inspectionCalls.map(c=>c.targetName.replace(/^_+/,''))),apiGroups=new Set(inspectionCalls.flatMap(c=>E.callEvidence(c.targetName).map(e=>e.group))),machineContext=inspectionChecks.length>0&&apiNames.size>0;
  const components=[],penalties=[];function add(label,points){if(points)components.push({label,points});}
  add('Tên hàm có mẫu kiểm tra cụ thể',name?12:0);add('Chuỗi có ngữ cảnh bảo mật cụ thể',context?18:strings.length?6:0);
  add('Nhóm dấu hiệu chức năng khác nhau',Math.min(18,groups.length*6));add('Tham chiếu mã tới chuỗi',xref?26:0);
  add('Lời gọi kiểm tra có tên cụ thể',calls.length||conditionPeer.length||nativeControl.length?14:0);add('Kiểm tra dùng trong điều kiện C',control.length||conditionPeer.length?36:genericControl.length?4:0);add('Giá trị trả về được dùng trong nhánh ARM64 có nguồn thanh ghi xác định',nativeControl.length?(control.length||conditionPeer.length?12:36):0);
  add('Gọi trực tiếp hàm kiểm tra có tên cụ thể',peer.length?8:0);
  add('API quan sát tiến trình/thư viện/bộ nhớ đã ánh xạ',Math.min(12,apiNames.size*6));add('Kết quả API quan sát được dùng trong nhánh',machineContext?24:0);add('Hội tụ nhiều nhóm API quan sát có điều kiện',machineContext&&apiGroups.size>=2?8:0);
  const cfg=root.OffsetCFG?.forRow(row,model)||null,cfgChecks=[...nativeControl,...inspectionChecks].filter(c=>c.cfgModeled),fullCFG=cfgChecks.some(c=>c.cfgVerified);
  add(fullCFG?'Nguồn kết quả tới điều kiện được đối chiếu CFG':'Nguồn kết quả trên CFG luồng thường; chưa xét cạnh ngoại lệ',cfgChecks.length?(fullCFG?6:2):0);
  add('Hai nhánh có hình dạng thoát sớm và tiếp tục khác nhau',cfgChecks.some(c=>c.guardShape)?(fullCFG?4:2):0);
  const byteMatches=root.OffsetSignatures?.forRow(row,model)||[];
  const corroborated=byteMatches.some(h=>h.atFunctionStart)&&(xref||control.length||conditionPeer.length||nativeControl.length||machineContext);
  add('Mẫu byte người dùng khớp đầu hàm, kèm bằng chứng cấu trúc',corroborated?4:0);
  if(byteMatches.length)penalties.push('Mẫu byte là prologue ARM64 phổ biến; chưa xác minh vai trò antiban.');
  let score=components.reduce((s,c)=>s+c.points,0);const life=root.OffsetAssessment.lifecycle(row.name),utility=/^(?:_*(?:printf|puts|fprintf|NSLog|os_log|memcmp|memcpy|CC_SHA\w*|SHA\d+|MD5|ptrace|sysctl)|.*(?:logger|logmessage))$/i.test(row.name);
  const semantic=name||context||calls.length||control.length||conditionPeer.length||peer.length||nativeControl.length||machineContext;
  if(!semantic){score=Math.min(score,30);penalties.push('Không có dấu hiệu kiểm tra bảo mật cụ thể; chỉ từ khóa/API chung.');}
  if(life&&!control.length&&!conditionPeer.length&&!nativeControl.length){score=Math.min(score,30);penalties.push('Hàm khởi tạo/vòng đời, thiếu kiểm tra trong điều kiện.');}
  if(utility){score=Math.min(score,20);penalties.push('Hàm tiện ích/ghi log/API chung.');}
  const structural=xref||control.length||conditionPeer.length||nativeControl.length||machineContext;
  if(!structural){score=Math.min(score,45);penalties.push('Thiếu tham chiếu chuỗi từ mã hoặc kiểm tra trong điều kiện C.');}
  if(machineContext&&!name&&!context&&!control.length&&!conditionPeer.length&&!nativeControl.length){const cap=apiGroups.size>=2?65:45;score=Math.min(score,cap);penalties.push('API quan sát vẫn có thể thuộc xử lý bình thường; điểm giới hạn '+cap+'.');}
  score=Math.min(100,score);
  const mapping=model?.map(row.va),inCode=!!model?.codeSection(row.va),metadata=metadataAddresses.has(row.va.toString());
  const address={conflict:row.addressConflict||null,status:model?(inCode&&mapping?(metadata?'Mốc hàm metadata và ánh xạ section mã':'Ánh xạ section mã; điểm đầu hàm chưa xác minh'):'Nhãn không ánh xạ được vào section mã'):'Chỉ có nhãn VA trong dump; chưa biết RVA/file offset',va:row.va,rva:inCode&&mapping?row.va-model.base:null,fileOffset:inCode&&mapping?mapping.fileOffset:null,verifiedRuntime:false};
  if(row.addressConflict){score=Math.min(score,20);penalties.push('Địa chỉ header IDA khác nhãn tên hàm; không đủ cơ sở chọn offset.');}
  if(model&&(!inCode||!mapping)){score=Math.min(score,30);penalties.push('Địa chỉ dump không ánh xạ section mã của Mach-O đang nạp.');}
  results.push({rowIndex:i,name:row.name,va:row.va,score,tier:score>=75?'Nhiều bằng chứng hội tụ':score>=55?'Ưu tiên đối chiếu':score>=35?'Đầu mối thăm dò':'Bằng chứng yếu',components,penalties,groups,evidence,controlChecks:[...control,...conditionPeer].slice(0,32),binaryChecks:[...nativeControl,...inspectionChecks],machineCalls:machine.calls,byteMatches,cfg,directCallees:peer.map(r=>({name:r.name,va:r.va})),address,bodyTruncated:!!row.bodyTruncated,flowTruncated:!!row.controlFlow?.truncated,conclusion:'Điểm ưu tiên đọc, không phải xác suất anticheat/antiban và không chứng minh hiệu quả thay đổi hàm.'});
 }
 return results.sort((a,b)=>b.score-a.score||(a.va<b.va?-1:a.va>b.va?1:0));
}

function rank(rows,model){
 const results=rankDirect(rows,model),direct=new Map(results.map(r=>[r.va.toString(),r])),byVA=new Map(rows.map(r=>[r.va.toString(),r])),names=new Map(),native=new Map();
 for(const r of rows){if(!names.has(r.name))names.set(r.name,r);else if(names.get(r.name)?.va!==r.va)names.set(r.name,null);}
 for(const c of model?.callGraph?.checks||[]){if(c.callerVA===null)continue;const key=c.callerVA.toString();if(!native.has(key))native.set(key,[]);if(native.get(key).length<32)native.get(key).push(c);}
 // Seeds remain the direct-evidence scores. Added candidates never seed another hop.
 const seedScores=new Map(results.map(r=>[r.va.toString(),r.score]));
 rows.forEach((row,rowIndex)=>{
  const links=[];
  function link(va,source,site){if(va===row.va)return;const score=seedScores.get(va.toString())||0;if(score<55||links.some(l=>l.va===va))return;links.push({va,name:byVA.get(va.toString())?.name||'',score,source,site});}
  for(const c of row.controlFlow?.checks||[]){const m=/^(?:sub_|FUN_)([0-9a-f]+)$/i.exec(c.call),target=m?byVA.get(BigInt('0x'+m[1]).toString()):names.get(c.call);if(target)link(target.va,'Điều kiện C: '+c.kind,null);}
  for(const c of native.get(row.va.toString())||[])link(c.targetVA,c.method,c.siteVA);
  if(!links.length)return;
  let r=direct.get(row.va.toString());
  const mapping=model?.map(row.va),code=!!model?.codeSection(row.va);
  if(!r){r={rowIndex,name:row.name,va:row.va,score:0,components:[],penalties:[],groups:[],evidence:[],cfg:root.OffsetCFG?.forRow(row,model)||null,controlChecks:[],binaryChecks:[],directCallees:[],bodyTruncated:!!row.bodyTruncated,flowTruncated:!!row.controlFlow?.truncated,address:{conflict:row.addressConflict||null,va:row.va,rva:mapping&&code?row.va-model.base:null,fileOffset:mapping&&code?mapping.fileOffset:null,verifiedRuntime:false,status:model?(mapping&&code?'Ánh xạ section mã; vai trò chưa xác minh':'Không ánh xạ section mã'):'Nhãn dump; chưa biết RVA/file offset'},conclusion:'Ứng viên qua việc dùng kết quả hàm khác; không truyền kết luận anticheat/antiban.'};results.push(r);direct.set(row.va.toString(),r);}
  r.contextLinks=links;
  if(row.addressConflict||(model&&(!mapping||!code))||root.OffsetAssessment.lifecycle(row.name)||/log|printf|puts|memcmp|memcpy|SHA\d|MD5/i.test(row.name))return;
  const score=Math.min(65,Math.max(...links.map(l=>l.score))-12);
  if(score>r.score){r.components.push({label:'Dùng kết quả ứng viên có bằng chứng trực tiếp trong điều kiện (một bước)',points:score-r.score});r.score=score;r.contextDerived=true;}
 });
 for(const r of results){r.tier=r.contextDerived?'Ứng viên qua điều kiện gọi hàm':r.score>=75?'Nhiều bằng chứng hội tụ':r.score>=55?'Ưu tiên đối chiếu':r.score>=35?'Đầu mối thăm dò':'Bằng chứng yếu';}
 return results.sort((a,b)=>b.score-a.score||(a.va<b.va?-1:a.va>b.va?1:0));
}
function shortlist(results,options={}){const minimum=options.mode==='explore'?35:55,limit=Math.max(1,Math.min(100,Number(options.limit)||25));const seen=new Set();return results.filter(r=>{const key=r.va.toString();if(r.score<minimum||seen.has(key))return false;seen.add(key);return true;}).slice(0,limit);}
const api={flow,specific,rank,shortlist,version:'1.0',analysisRevision:'cfg-return-flow-v1',scoreMeaning:'Ordinal evidence priority, not calibrated probability.'};root.OffsetFocus=api;if(typeof module!=='undefined')module.exports=api;
})(typeof globalThis==='undefined'?this:globalThis);
