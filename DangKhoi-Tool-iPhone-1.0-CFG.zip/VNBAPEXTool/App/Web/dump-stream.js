/* Incremental UTF-8 C-dump reader; keeps bounded previews and scans the full input.
   Addresses are labels, not verified live addresses. */
(function(root){
'use strict';
function create(){
 const E=root.OffsetEvidence,rows=[],maxRows=100000,perBody=32768,totalBudget=8*1024*1024;
 let budget=totalBudget,state='code',slash=false,star=false,escape=false,depth=0,head='',literal='',quote='',line=1,active=null,token='',pendingCall='',skippedBodies=0,totalChars=0,asmLines=0,linePrefix='',prefix='',pendingAddress=null;
 function evidence(items){if(active)active.evidence=E.unique([...active.evidence,...items]);}
 function identifier(){if(token){pendingCall=token;token='';}}
 function normal(c){
  if(depth===0){
   if(c==='{'){
    const labelled=/\b((?:sub_|FUN_)[0-9a-fA-F]+)\s*\([^;{}]*\)\s*(?:(?:const|noexcept)\s*)?$/.exec(head);
    const m=labelled||(pendingAddress!==null?/\b([A-Za-z_$][\w$]*)\s*\([^;{}]*\)\s*(?:(?:const|noexcept)\s*)?$/.exec(head):null);
    if(m){if(rows.length>=maxRows)throw Error('Dump vượt 100.000 hàm; chia file để phân tích.');active={name:m[1],va:labelled?BigInt('0x'+m[1].replace(/^(sub_|FUN_)/,'')):pendingAddress,base:null,rva:null,fileOffset:null,sliceOffset:null,sources:[labelled?'C dump: địa chỉ suy từ tên, chưa xác minh':'C dump: địa chỉ từ header IDA, chưa xác minh'],body:'',previewParts:[],previewBuffer:'',previewLength:0,signature:head.trim().slice(-4096),calls:[],stringAnchors:[],evidence:[],dumpLine:line,bodyTruncated:false,callsTruncated:false,addressConflict:labelled&&pendingAddress!==null&&BigInt('0x'+m[1].replace(/^(sub_|FUN_)/,''))!==pendingAddress?{header:pendingAddress,label:BigInt('0x'+m[1].replace(/^(sub_|FUN_)/,''))}:null};if(root.OffsetFocus)active.flow=root.OffsetFocus.flow();capture('{');}
    pendingAddress=null;depth=1;head='';token='';pendingCall='';
   }else if(c===';'||c==='}'){head='';pendingAddress=null;}else {head+=c;if(head.length>16384)head=head.slice(-8192);}
   return;
  }
  if(active?.flow)active.flow.push(c);
  if(/[A-Za-z0-9_$]/.test(c)){token+=c;if(token.length>256)token=token.slice(-256);}
  else {identifier();if(c==='('&&pendingCall){if(!['if','for','while','switch','sizeof','return'].includes(pendingCall)){
   evidence(E.callEvidence(pendingCall));evidence(E.textEvidence(pendingCall,'Tên lời gọi trong dump C'));
   if(active&&!active.calls.includes(pendingCall)){if(active.calls.length<256)active.calls.push(pendingCall);else active.callsTruncated=true;}
  }pendingCall='';}else if(!/\s/.test(c))pendingCall='';}
  if(c==='{')depth++;
  if(c==='}'&&--depth===0){if(active){if(active.flow){active.controlFlow=active.flow.finish();delete active.flow;}active.body=active.previewParts.join('')+active.previewBuffer;delete active.previewParts;delete active.previewBuffer;delete active.previewLength;if(active.bodyTruncated)skippedBodies++;rows.push(active);}active=null;head='';token='';pendingCall='';}
 }
 function capture(c){if(active){if(active.previewLength+c.length<=perBody&&budget>=c.length){active.previewBuffer+=c;if(active.previewBuffer.length>=1024){active.previewParts.push(active.previewBuffer);active.previewBuffer='';}active.previewLength+=c.length;budget-=c.length;}else active.bodyTruncated=true;}}
 function code(c){
  if(slash){slash=false;if(c==='/'){normal(' ');state='line';return;}if(c==='*'){normal(' ');state='block';star=false;return;}normal('/');}
  if(c==='/'){slash=true;return;}
  if(c==='"'||c==="'"){identifier();if(active?.flow)active.flow.push(' ');state='literal';quote=c;literal='';escape=false;if(depth===0)head+=' ';return;}
  normal(c);
 }
 return {
  push(text){if(text.includes('\0'))throw Error('Dump chứa byte NUL: kiểm tra mã hóa UTF-16 hoặc chọn văn bản C thay vì file nhị phân.');if(prefix.length<4096)prefix=(prefix+text).slice(0,4096);totalChars+=text.length;for(const c of text){
   capture(c);
   if(c==='\n'){if(depth===0&&state==='line'){const label=/^\s*\/\/-{3,}\s*\(([0-9A-Fa-f]{4,16})\)\s*-{3,}/.exec(linePrefix);if(label)pendingAddress=BigInt('0x'+label[1]);}if(/^[0-9A-Fa-f]{8,16}\s+[0-9A-Fa-f]{8}\s+\S/.test(linePrefix))asmLines++;linePrefix='';line++;}else if(linePrefix.length<100)linePrefix+=c;
   if(state==='line'){if(c==='\n'){state='code';if(depth===0)head+='\n';}continue;}
   if(state==='block'){if(star&&c==='/'){state='code';star=false;if(depth===0)head+=' ';}else star=c==='*';continue;}
   if(state==='literal'){if(escape){escape=false;if(literal.length+2<=4096)literal+='\\'+c;continue;}if(c==='\\'){escape=true;continue;}if(c===quote){const decoded=E.decodeCLiteral(literal);if(active&&root.OffsetFingerprint&&literal.length>=4&&active.stringAnchors.length<16){const key=root.OffsetFingerprint.hash(decoded);if(!active.stringAnchors.includes(key))active.stringAnchors.push(key);}evidence(E.textEvidence(decoded,'Chuỗi trong thân hàm dump C'));state='code';}else if(literal.length<4096)literal+=c;continue;}
   code(c);
  }},
  finish(){if(active||state==='block'||state==='literal')throw Error('Dump C kết thúc giữa hàm/chuỗi/comment ở dòng '+line+(active?' ('+active.name+')':'')+'; file có thể bị cắt ngắn.');if(!rows.length&&/\b(?:class|namespace)\s+[A-Za-z_]|\/\/\s*RVA:\s*0x/i.test(prefix))throw Error('Có dấu hiệu dump.cs / C#: nút này nhận mã giả C (so.c), không phải metadata IL2CPP dump.cs.');if(!rows.length)throw Error(asmLines?'Đây là dump ASM, không phải C. ASM do app xuất dùng để đọc lệnh; không nhập qua nút dump C.':'Không thấy định nghĩa sub_HEX/FUN_HEX hoặc hàm có header địa chỉ IDA. Dump phải có thân hàm C và nhãn địa chỉ.');return {rows,stats:{functions:rows.length,previewCharacters:totalBudget-budget,truncatedPreviews:skippedBodies,charactersRead:totalChars,maxRows,perBody,totalBudget}};}
 };
}
// Detect BOM before decoding; keep TextDecoder state across arbitrary byte chunks.
function createDecoder(){
 let decoder=null,encoding=null,prefix=new Uint8Array(0),ended=false;
 function decode(bytes,final){
  if(ended)throw Error('Bộ đọc văn bản đã kết thúc.');
  if(!(bytes instanceof Uint8Array))throw Error('Cần dữ liệu byte để đọc dump.');
  if(!decoder){
   const merged=new Uint8Array(prefix.length+bytes.length);merged.set(prefix);merged.set(bytes,prefix.length);prefix=merged;
   if(prefix.length<4&&!final)return '';
   const b=prefix;
   if((b[0]===0xff&&b[1]===0xfe&&b[2]===0&&b[3]===0)||(b[0]===0&&b[1]===0&&b[2]===0xfe&&b[3]===0xff))throw Error('UTF-32 chưa được hỗ trợ; lưu dump thành UTF-8 hoặc UTF-16.');
   encoding=b[0]===0xff&&b[1]===0xfe?'utf-16le':b[0]===0xfe&&b[1]===0xff?'utf-16be':b[0]!==0&&b[1]===0&&b[2]!==0&&b[3]===0?'utf-16le':b[0]===0&&b[1]!==0&&b[2]===0&&b[3]!==0?'utf-16be':'utf-8';
   decoder=new TextDecoder(encoding,{fatal:true});bytes=prefix;prefix=new Uint8Array(0);
  }
  try{const text=decoder.decode(bytes,{stream:!final});if(final)ended=true;return text;}
  catch(e){throw Error('Văn bản '+encoding+' không hợp lệ hoặc bị cắt giữa ký tự. Hãy lưu lại dump thành UTF-8.');}
 }
 return {push(bytes){return decode(bytes,false);},finish(){return decode(new Uint8Array(0),true);},get encoding(){return encoding;}};
}
const api={create,createDecoder};root.OffsetDumpStream=api;if(typeof module!=='undefined')module.exports=api;
})(typeof globalThis==='undefined'?this:globalThis);
