import UIKit
import AVFoundation

// Native playback avoids the user-gesture restriction on HTML audio in WKWebView.
final class BackgroundMusic: NSObject {
    private var player: AVAudioPlayer?
    private(set) var enabled = true
    private var interrupted = false
    private(set) var errorMessage: String?
    var changed: (() -> Void)?
    var playing: Bool { player?.isPlaying == true }

    override init() {
        super.init()
        NotificationCenter.default.addObserver(self, selector: #selector(activate), name: UIApplication.didBecomeActiveNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(pauseForBackground), name: UIApplication.willResignActiveNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(interruption(_:)), name: AVAudioSession.interruptionNotification, object: nil)
        do {
            guard let url = Bundle.main.url(forResource: "background", withExtension: "mp3") else {
                throw DeskPatchFailure.invalid("Không tìm thấy nhạc nền trong bundle.")
            }
            player = try AVAudioPlayer(contentsOf: url)
            player?.numberOfLoops = -1
            player?.volume = 0.25
            player?.prepareToPlay()
            resume()
        } catch { errorMessage = error.localizedDescription }
    }
    deinit { NotificationCenter.default.removeObserver(self) }
    func setEnabled(_ value: Bool) {
        enabled = value
        if value { resume() } else {
            player?.pause()
            try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
        }
        changed?()
    }
    @objc private func activate() { resume(); changed?() }
    @objc private func pauseForBackground() {
        player?.pause()
        try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
        changed?()
    }
    private func resume() {
        guard enabled, !interrupted, UIApplication.shared.applicationState == .active, let player else { return }
        do {
            let session = AVAudioSession.sharedInstance()
            try session.setCategory(.playback, mode: .default, options: [.mixWithOthers])
            try session.setActive(true)
            guard player.play() else { throw DeskPatchFailure.invalid("Không phát được nhạc nền.") }
            errorMessage = nil
        } catch { errorMessage = error.localizedDescription }
    }
    @objc private func interruption(_ note: Notification) {
        guard let value = note.userInfo?[AVAudioSessionInterruptionTypeKey] as? UInt,
              let type = AVAudioSession.InterruptionType(rawValue: value) else { return }
        if type == .began { interrupted = true; player?.pause() }
        else {
            interrupted = false
            let raw = note.userInfo?[AVAudioSessionInterruptionOptionKey] as? UInt ?? 0
            if AVAudioSession.InterruptionOptions(rawValue: raw).contains(.shouldResume) { resume() }
        }
        changed?()
    }
}
