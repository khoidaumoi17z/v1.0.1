const assert=require('node:assert/strict');
require('../App/Web/evidence.js');const P=require('../App/Web/fingerprints.js');const R=require('../App/Web/relations.js');require('../App/Web/assessment.js');const F=require('../App/Web/focus.js'),D=require('../App/Web/dump-stream.js');
function parse(text,n=17){const p=D.create();for(let i=0;i<text.length;i+=n)p.push(text.slice(i,i+n));return p.finish().rows;}
function body(local='v1',callee='sub_2000'){return `int ${local} = CheckHook(); if(${local}) { puts("jailbreak hook detected"); ReportSecurity(); return -1; } ${callee}(); if(CheckDebugger()) { puts("debugger attached"); return -2; } for(int a1=0;a1<7;a1++){consume(a1);} return 0;`;}
const old=parse('int sub_1000(){'+body()+'}'),newer=parse('int sub_9000(){'+body('v4','sub_8000')+'}');
assert.deepEqual(old[0].controlFlow.fingerprint.hashes,newer[0].controlFlow.fingerprint.hashes);
const ranked=F.rank(old,null);assert(ranked[0].score>=75);
const snap=P.snapshot(old,null,ranked,{dumpName:'old.c'}),comparison=P.compare(snap,newer,null);
assert.equal(comparison.stats.supported,1);assert.equal(comparison.matches[0].candidates[0].va,0x9000n);assert.equal(comparison.matches[0].candidates[0].address.fileOffset,null);
const duplicate=parse('int sub_9000(){'+body()+'}\nint sub_A000(){'+body()+'}');assert.equal(P.compare(snap,duplicate,null).stats.supported,0);assert.match(P.compare(snap,duplicate,null).matches[0].status,/Mơ hồ/);
const oldDuplicates=P.snapshot(duplicate,null,F.rank(duplicate,null));const shared=P.compare(oldDuplicates,newer,null);assert.equal(shared.stats.supported,0);assert(shared.matches.every(m=>/nhiều hàm cũ/.test(m.status)));
const unrelated=parse('int sub_9000(){int v=7;while(v){v--;puts("ordinary data");} return v;}');assert.equal(P.compare(snap,unrelated,null).stats.supported,0);
const justNames=P.compareFeatures({name:'checkhook',strings:[],calls:[],shapes:[]},{name:'checkhook',strings:[],calls:[],shapes:[]});assert.equal(justNames.score,10);
const weakConflict=parse('//----- (0000000000009999) -----\nint sub_9000(){'+body()+'}');assert.equal(P.compare(snap,weakConflict,null).stats.supported,0);
// Context expansion admits a conditional caller, but never recursively promotes its caller.
const contextRows=parse('int sub_1000(){'+body()+'}\nint sub_3000(){if(sub_1000())return -1;return 0;}\nint sub_4000(){if(sub_3000())return -1;return 0;}\nvoid sub_5000(){sub_1000();}');
const context=F.rank(contextRows,null);assert(context.find(r=>r.va===0x3000n)?.contextDerived);assert(!F.shortlist(context).some(r=>r.va===0x4000n||r.va===0x5000n));
for(const assignment of ['v *= 0','v &= 0','v <<= 1','v /= 2']){const rows=parse('int sub_1000(){v=CheckHook();'+assignment+';if(v)return 1;}');assert.equal(F.shortlist(F.rank(rows,null)).length,0);}
assert.equal(F.shortlist(F.rank(parse('int sub_1000(){v=CheckHook();if((v=0))return 1;}'),null)).length,0);
assert(F.shortlist(F.rank(parse('int sub_1000(){_DWORD v1 = (unsigned int) CheckHook();if(v1)return 1;}'),null)).length);
// Full-stream signatures include content beyond the bounded preview.
const long=parse('int sub_1000(){'+'x++;'.repeat(10000)+body()+'}');assert(long[0].bodyTruncated);assert(long[0].controlFlow.fingerprint.count>30000);
const functions=parse(Array.from({length:120},(_,i)=>'int sub_'+(0x1000+i*16).toString(16)+'(){if(CheckHook())return 1;}').join('\n'));assert.equal(F.shortlist(F.rank(functions,null)).length,25);assert.equal(F.shortlist(F.rank(functions,null),{limit:1000}).length,100);
// Binary fingerprints ignore branch displacement while retaining opcode/register structure.
assert.equal(P.armWord(0x94000008),P.armWord(0x94001008));assert.notEqual(P.armWord(0x34000040),P.armWord(0x34000041));
function machine(base,call){const bytes=Buffer.alloc(128);for(let i=0;i<32;i++)bytes.writeUInt32LE((0x8b010000|((i%24)<<5)|(i%24))>>>0,i*4);bytes.writeUInt32LE(call,8);const row={va:base,name:'sub_'+base.toString(16),calls:[]},m={rows:[row],base,sections:[{va:base,size:128n,flags:0x80000400,name:'__text'}],map:v=>v>=base&&v<base+128n?{fileOffset:v-base}:null};R.binary(bytes,m);return row.binaryFingerprint;}
assert.deepEqual(machine(0x1000n,0x94000008).hashes,machine(0x9000n,0x94001008).hashes);
console.log('PASS v9 normalized C/ARM64 sketches, unique/ambiguous/many-to-one relocation review, address conflicts, one-hop conditional context, assignment kills, 25/100 limits and full-stream signatures.');
const E=global.OffsetEvidence;
assert.equal(E.decodeCLiteral(String.raw`\x6a\x61\x69\x6c\x62\x72\x65\x61\x6b`),'jailbreak');
assert.equal(E.decodeCLiteral(String.raw`\u006aailbreak`),'jailbreak');
assert.equal(E.decodeCLiteral(String.raw`\152ailbreak`),'jailbreak');
assert.equal(E.decodeCLiteral(String.raw`\x1234`),String.raw`\x1234`);
const encoded=parse(String.raw`int sub_1000(){if(CheckHook()){puts("\x6a\x61\x69\x6c\x62\x72\x65\x61\x6b");return -1;}}`);
assert(encoded[0].evidence.some(e=>e.group==='environment'));assert(F.rank(encoded,null)[0].score>=75);
