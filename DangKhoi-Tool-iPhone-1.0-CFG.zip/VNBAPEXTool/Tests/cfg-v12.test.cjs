const assert=require('node:assert/strict'),G=require('../App/Web/cfg.js');
function scan(words,options={}){const bytes=Buffer.alloc(words.length*4);words.forEach((w,i)=>bytes.writeUInt32LE(w>>>0,i*4));const section={name:'__text',flags:0x80000400,va:0x1000n,size:BigInt(bytes.length)},model={base:0n,rows:[{name:'sub_1000',va:0x1000n}],imports:[{name:'_sysctl',kind:'stub',va:0x1100n}],sections:[section,...(options.exceptions?[{name:'__gcc_except_tab',va:0x2000n,size:16n}]:[])],map:va=>va>=section.va&&va<section.va+section.size?{fileOffset:va-section.va}:null,codeSection:va=>va>=section.va&&va<section.va+section.size?section:null};model.cfg=G.analyze(bytes,model);return {cfg:model.cfg,model};}
// BL -> B -> MOV -> condition; the gap is unreachable, value crosses a block.
let {cfg,model}=scan([0x94000040,0x14000002,0xd503201f,0xaa0003f3,0xb4000053,0xd65f03c0,0xd65f03c0]);assert.equal(cfg.checks.length,1);assert.equal(cfg.checks[0].crossBlock,true);assert.equal(cfg.checks[0].cfgVerified,true);assert.equal(cfg.functions[0].unreachableInstructions,1);assert.equal(G.reachable(model.rows[0],0x1008n,model),false);
// A diamond: same source on BOTH predecessors is accepted.
({cfg}=scan([0x94000040,0x34000062,0xaa0003f3,0x14000002,0xaa0003f3,0xb4000053,0xd65f03c0,0xd65f03c0]));assert(cfg.checks.some(c=>c.conditionSiteVA===0x1014n));
// One predecessor writes a constant: must-agree analysis rejects it.
({cfg}=scan([0x94000040,0x34000062,0xaa0003f3,0x14000002,0xd2800013,0xb4000053,0xd65f03c0,0xd65f03c0]));assert(!cfg.checks.some(c=>c.conditionSiteVA===0x1014n));assert(cfg.stats.ambiguousJoins>0);
// No propagation through unsupported instruction, unknown BR or NZCV mistaken for XZR.
for(const words of [[0x94000040,0,0xb4000040,0xd65f03c0],[0x94000040,0xd61f0200,0xb4000040,0xd65f03c0],[0x94000040,0x7100001f,0xaa1f03f3,0xb4000053,0xd65f03c0,0xd65f03c0]])assert.equal(scan(words).cfg.checks.length,0);
// A loop can retain a value for arbitrarily long: age bound fails closed.
({cfg}=scan([0x94000040,0xaa0003f3,0x34000042,0x17ffffff,0xb4000053,0xd65f03c0,0xd65f03c0]));assert.equal(cfg.checks.length,0);assert.equal(cfg.stats.flowLimitedFunctions,0);
// More than 64 instructions and unknown fall-through function boundary are rejected.
assert.equal(scan([0x94000040,...Array(65).fill(0xd503201f),0xb4000040,0xd65f03c0]).cfg.checks.length,0);assert.equal(scan([0x94000040,0xb4000020]).cfg.functions[0].complete,false);
// Exception metadata disables dead-code deletion and downgrades proof to normal flow.
({cfg,model}=scan([0x94000040,0x14000002,0xd503201f,0xaa0003f3,0xb4000053,0xd65f03c0,0xd65f03c0],{exceptions:true}));assert.equal(cfg.checks[0].cfgVerified,false);assert.equal(cfg.checks[0].cfgMode,'normal-flow-only');assert.equal(G.reachable(model.rows[0],0x1008n,model),null);
// Early-return shape is a structure observation, not a ban/bypass classification.
({cfg}=scan([0x94000040,0xb4000060,0xd65f03c0,0xd503201f,0x9400003c,0xd65f03c0]));assert.equal(cfg.checks[0].guardShape,true);
assert.equal(scan(Array(8193).fill(0xd503201f)).cfg.stats.oversizedFunctions,1);
console.log('PASS CFG cross-block flow, same/conflicting diamond joins, unknown instruction/control, XZR vs NZCV, loops/age, boundary/caps, exception downgrade and early-return shape.');
// Production integration: old straight-line engine misses B-crossing, CFG adds a candidate.
require('../App/Web/evidence.js');require('../App/Web/fingerprints.js');require('../App/Web/machine.js');const R=require('../App/Web/relations.js');require('../App/Web/assessment.js');const F=require('../App/Web/focus.js');
function integrated(words,exceptions=false){const base=scan(words,{exceptions}),bytes=Buffer.alloc(words.length*4);words.forEach((w,i)=>bytes.writeUInt32LE(w>>>0,i*4));base.model.stringFindings=[];base.model.callGraph=R.binary(bytes,base.model);return base.model;}
let m=integrated([0x94000040,0x14000002,0xd503201f,0xaa0003f3,0xb4000053,0xd65f03c0,0xd65f03c0]);assert.equal(m.callGraph.checks.length,1);assert.equal(m.callGraph.checks[0].crossBlock,true);assert.equal(F.shortlist(F.rank(m.rows,m),{mode:'explore'}).length,1);
m=integrated([0x14000002,0x9400003f,0xd65f03c0]);assert.equal(m.callGraph.machineCalls.length,0);assert.equal(m.callGraph.stats.cfg.pruned.calls,1);
m=integrated([0x14000002,0x9400003f,0xd65f03c0],true);assert.equal(m.callGraph.machineCalls.length,1);assert.equal(m.callGraph.stats.cfg.pruned.calls,0);
console.log('PASS production integration: cross-block candidate, unreachable-call exclusion, exception-metadata retention.');
