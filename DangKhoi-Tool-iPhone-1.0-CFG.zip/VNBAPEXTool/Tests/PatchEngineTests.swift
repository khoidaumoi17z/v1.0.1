import Foundation

@main struct PatchEngineTests {
    static func main() throws {
        let folder = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString, isDirectory: true)
        try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: folder) }
        let input = folder.appendingPathComponent("input"), output = folder.appendingPathComponent("output")
        let original = Data((0..<64).map { UInt8($0) })
        try original.write(to: input)
        let ret = try DeskPatchEngine.bytes("C0035FD6")
        let edits = [DeskPatchEdit(offset: 4, before: original.subdata(in: 4..<8), after: ret), DeskPatchEdit(offset: 16, before: original.subdata(in: 16..<20), after: ret)]
        try DeskPatchEngine.export(input: input, output: output, edits: edits)
        let patched = try Data(contentsOf: output)
        let sourceAfter = try Data(contentsOf: input)
        precondition(sourceAfter == original && patched.count == original.count)
        for i in 0..<64 { if !(4..<8).contains(i) && !(16..<20).contains(i) { precondition(patched[i] == original[i]) } }
        precondition(patched.subdata(in: 4..<8) == ret && patched.subdata(in: 16..<20) == ret)
        precondition(DeskPatchEngine.hex(ret) == "C0035FD6")
        func reject(_ edits: [DeskPatchEdit]) throws {
            let failed = folder.appendingPathComponent(UUID().uuidString)
            var rejected = false
            do { try DeskPatchEngine.export(input: input, output: failed, edits: edits) } catch { rejected = true }
            precondition(rejected && !FileManager.default.fileExists(atPath: failed.path))
        }
        try reject([DeskPatchEdit(offset: 4, before: Data(repeating: 0, count: 4), after: ret)])
        try reject([edits[0], DeskPatchEdit(offset: 6, before: original.subdata(in: 6..<10), after: ret)])
        try reject([DeskPatchEdit(offset: 63, before: Data(repeating: 0, count: 4), after: ret)])
        try reject([DeskPatchEdit(offset: 4, before: original.subdata(in: 4..<8), after: original.subdata(in: 4..<8))])
        try reject([])
        var badHexRejected = false
        do { _ = try DeskPatchEngine.bytes("0xC0035FD6") } catch { badHexRejected = true }
        precondition(badHexRejected)
        print("PASS native patch engine: exact bytes, multi-edit, original preservation, unchanged bytes, preconditions, overlaps, bounds and failed-output cleanup.")
    }
}
