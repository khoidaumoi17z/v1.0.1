const assert=require('node:assert/strict');
const E=require('../App/Web/evidence.js');require('../App/Web/relations.js');require('../App/Web/assessment.js');
const F=require('../App/Web/focus.js'),D=require('../App/Web/dump-stream.js');
function parse(s,n=17){const p=D.create();for(let i=0;i<s.length;i+=n)p.push(s.slice(i,i+n));return p.finish().rows;}
const source=`//----- (0000000000001000) ----------------------------------------------------
int CheckIntegrityGate(void) { if (CheckHook()) { puts("jailbreak detected"); return -1; } return 0; }
void sub_2000(){ printf("jailbreak integrity"); }
void sub_3000(){ memcmp(0,0,0); }
void sub_4000(){ AnoSDKInit(); }
void sub_5000(){ CheckIntegrityGate(); }
void sub_6000(){ int v1 = CheckDebugger(); if(v1) return -1; }
void sub_7000(){ int v1 = CheckDebugger(); v1=0; if(v1) return -1; }
void sub_8000(){ /* if(CheckHook()) */ puts("if(CheckHook())"); }
`;
for(const n of [1,2,7,65536]){
 const rows=parse(source,n),rank=F.rank(rows,null),top=F.shortlist(rank);
 assert.equal(rows[0].name,'CheckIntegrityGate');assert.equal(rows[0].va,0x1000n);assert.match(rows[0].sources[0],/header IDA/);
 assert.equal(top[0].name,'CheckIntegrityGate');assert(top[0].score>=75);
 assert(top.some(r=>r.va===0x6000n));assert(!top.some(r=>[0x2000n,0x3000n,0x4000n,0x5000n,0x7000n,0x8000n].includes(r.va)));
 assert.equal(top[0].address.rva,null);assert.equal(top[0].address.fileOffset,null);
 assert.equal(rows[5].controlFlow.checks[0].kind,'local-assignment-condition');assert.equal(rows[6].controlFlow.checks.length,0);
}
const long=parse('void sub_A000(){'+'x++;'.repeat(10000)+'if(CheckHook()) return -1;}');assert(long[0].bodyTruncated);assert(F.shortlist(F.rank(long,null)).length===1);
const ordinary=parse('void sub_B000(){ if(memcmp(a,b,3)) return -1; puts("checksum mismatch"); }');assert.equal(F.shortlist(F.rank(ordinary,null)).length,0);
const overwrites=parse('void sub_C000(){ v = CheckHook(); ++v; if(v) return -1; }');assert.equal(F.shortlist(F.rank(overwrites,null)).length,0);
const many=parse(Array.from({length:20},(_,i)=>`void sub_${(0x10000+i*16).toString(16)}(){ if(CheckHook()) return -1; }`).join('\n'));assert.equal(F.shortlist(F.rank(many,null)).length,20);assert.equal(F.shortlist(F.rank(many,null),{limit:3}).length,3);assert.equal(F.shortlist(F.rank(many,null),{limit:100}).length,20);
const r={va:0x1000n,name:'sub_1000',calls:[],sources:['LC_FUNCTION_STARTS'],rva:0n,fileOffset:32n};
const model={base:0x1000n,rows:[r],callGraph:{edges:[],stats:{},references:[{callerVA:0x1000n,siteVA:0x1000n,stringVA:0x2000n,text:'jailbreak detected; detect hook',method:'ADR',evidence:E.textEvidence('jailbreak detected; detect hook','string')}]},map:va=>va===0x1000n?{fileOffset:32n}:null,codeSection:va=>va===0x1000n?{name:'__text'}:null};
const binaryTop=F.shortlist(F.rank([r],model));assert.equal(binaryTop.length,1);assert.equal(binaryTop[0].address.fileOffset,32n);assert.equal(binaryTop[0].address.rva,0n);
const wrong={...r,va:0x9000n,evidence:E.textEvidence('jailbreak integrity','body'),controlFlow:{checks:[{call:'CheckHook',kind:'direct-condition'}]}};assert.equal(F.shortlist(F.rank([wrong],model)).length,0);
assert(!JSON.stringify(F.shortlist(F.rank(parse(source),null)),(k,v)=>typeof v==='bigint'?v.toString():v).includes('probabilityPercent'));
console.log('PASS v8 strict ranking, false-positive controls, top limits, named IDA headers, full-stream C conditions, local overwrite rejection, binary XREF and typed offsets.');
const R=global.OffsetRelations;
function machineFixture(words){const bytes=Buffer.alloc(64);words.forEach((w,i)=>bytes.writeUInt32LE(w>>>0,i*4));const m={encrypted:false,base:0x1000n,rows:[{va:0x1000n,name:'sub_1000',calls:[],sources:['LC_FUNCTION_STARTS']},{va:0x1020n,name:'CheckHook',calls:[],sources:['symbol']}],sections:[{name:'__text',flags:0x80000400,va:0x1000n,size:64n}],map:va=>va>=0x1000n&&va<0x1040n?{fileOffset:va-0x1000n}:null,codeSection:va=>va>=0x1000n&&va<0x1040n?{name:'__text'}:null};m.callGraph=R.binary(bytes,m);return m;}
for(const words of [[0x94000008,0x34000040],[0x94000008,0xb5000040],[0x94000008,0x36000040],[0x94000008,0x7100001f,0x54000040],[0x94000008,0xf100001f,0x54000041]]){const m=machineFixture(words);assert.equal(m.callGraph.checks.length,1);assert(F.shortlist(F.rank(m.rows,m)).some(r=>r.va===0x1000n));}
for(const words of [[0x94000008,0x34000041],[0x94000008,0xd2800000,0x34000040],[0x94000008,0x7100041f,0x54000040],[0x94000008,0x7100003f,0x54000040]]){assert.equal(machineFixture(words).callGraph.checks.length,0);}
const encrypted=machineFixture([0x94000008,0x34000040]);assert.equal(R.binary(Buffer.alloc(64),{...encrypted,encrypted:true}).checks.length,0);
for(const code of ['if(sizeof(CheckHook())) return -1;','if(0 && CheckHook()) return -1;','v=CheckHook(); update(&v); if(v) return -1;'])assert.equal(F.shortlist(F.rank(parse('void sub_D000(){'+code+'}'),null)).length,0);
const equalCheck=parse('void sub_E000(){ v=CheckHook(); if(v==0) return -1; }');assert.equal(F.shortlist(F.rank(equalCheck,null)).length,1);
console.log('PASS adjacent BL return-register branch patterns, wrong register/clobber/immediate/encryption rejection, sizeof/dead-condition and unknown-call invalidation.');
const conflict=parse('//----- (0000000000009999) -----\nvoid sub_1000(){if(CheckHook())return -1;}');assert(conflict[0].addressConflict);assert.equal(F.shortlist(F.rank(conflict,null)).length,0);
