const assert=require('node:assert/strict'),P=require('../App/Web/patch.js');
const section={va:0x100001000n,size:0x100n,name:'__text'};
const model={base:0x100000000n,sections:[section],map:va=>va>=section.va&&va<section.va+section.size?{fileOffset:va-section.va+0x300n}:null,codeSection:va=>va>=section.va&&va<section.va+section.size?section:null};
assert.equal(P.resolve(model,0x500,'file','0x304',4).va,0x100001004n);
assert.equal(P.resolve(model,0x500,'rva','0x1004',4).offset,0x304);
assert.equal(P.resolve(model,0x500,'va','0x100001004',4).offset,0x304);
assert.throws(()=>P.resolve(model,0x500,'file','0x20',4));assert.throws(()=>P.resolve(model,0x500,'va','0x100001003',4));assert.throws(()=>P.resolve(model,0x500,'file','0x3FC',8));assert.throws(()=>P.resolve({...model,encrypted:true},0x500,'file','0x304',4));assert.throws(()=>P.resolve(model,104857601,'file','0x304',4));
assert.equal(P.hex(P.parseBytes('C0 03 5F D6')),'C0035FD6');for(const s of ['','C0035FD','0xC0035FD6','GG','AA'.repeat(257)])assert.throws(()=>P.parseBytes(s));
const bytes=Uint8Array.from({length:64},(_,i)=>i),p=[{offset:4,before:'04050607',after:'C0035FD6'},{offset:16,before:'10111213',after:'C0035FD6'}],out=P.apply(bytes,p);
assert.equal(P.hex(out.slice(4,8)),'C0035FD6');assert.equal(P.hex(out.slice(16,20)),'C0035FD6');assert.equal(out.length,bytes.length);
for(let i=0;i<bytes.length;i++){assert.equal(bytes[i],i);if(!(i>=4&&i<8||i>=16&&i<20))assert.equal(out[i],bytes[i]);}
assert.throws(()=>P.apply(bytes,[{...p[0],before:'00000000'}]));assert.throws(()=>P.apply(bytes,[p[0],{...p[0],offset:6}]));assert.throws(()=>P.apply(bytes,[{offset:63,before:'0000',after:'FFFF'}]));assert.throws(()=>P.apply(bytes,[{...p[0],after:p[0].before}]));assert.throws(()=>P.apply(bytes,[{...p[0],before:'04'}]));assert.throws(()=>P.apply(bytes,[]));
const buffer=Buffer.from(bytes),copy=P.apply(buffer,p);assert.equal(P.hex(buffer),P.hex(bytes));assert.equal(P.hex(copy.slice(4,8)),'C0035FD6');
// FAT map resolves addresses against whole-file offset, not slice-local offset.
const fatModel={...model,map:va=>{const m=model.map(va);return m?{fileOffset:m.fileOffset+0x1000n}:null;}};
assert.equal(P.resolve(fatModel,0x1500,'va','0x100001004',4).offset,0x1304);assert.throws(()=>P.resolve(fatModel,0x1500,'file','0x304',4));
console.log('PASS v11 patch plans: exact bytes, VA/RVA/whole-file FAT conversion, code bounds/alignment/encryption, multi-patch, overlaps, preconditions, size and original preservation.');
