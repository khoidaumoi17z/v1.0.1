const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const E=require('../App/Web/evidence.js');
const D=require('../App/Web/dump-stream.js');
const source='\ufeffint64_t sub_1000(void *p) { puts("jailbreak detected tiếng Việt"); return CheckDebugger(p); }\nvoid FUN_1010() noexcept { CheckHook(); }';
function encoded(kind,bom=true){
 if(kind==='utf-8')return Buffer.from(source,'utf8');
 let bytes=Buffer.from(source,'utf16le');if(!bom)bytes=bytes.subarray(2);
 if(kind==='utf-16be'){bytes=Buffer.from(bytes);bytes.swap16();}return bytes;
}
for(const encoding of ['utf-8','utf-16le','utf-16be'])for(const bom of [true,false])for(const n of [1,2,3,7,64,65536]){
 const decoder=D.createDecoder(),parser=D.create(),bytes=encoded(encoding,bom);
 for(let i=0;i<bytes.length;i+=n)parser.push(decoder.push(bytes.subarray(i,i+n)));
 parser.push(decoder.finish());const result=parser.finish();
 assert.equal(decoder.encoding,encoding);assert.equal(result.rows.length,2);
 assert.match(result.rows[0].body,/tiếng Việt/);assert(result.rows[0].evidence.some(e=>e.group==='debug'));
 assert(result.rows[1].evidence.some(e=>e.group==='hook'));
 assert(!('previewBuffer' in result.rows[0]));
}
assert.throws(()=>{const d=D.createDecoder();d.push(Buffer.from([0xff,0xfe,0,0]));},/UTF-32/);
assert.throws(()=>{const d=D.createDecoder();d.push(Buffer.from([0x61,0x62,0x63,0xc3]));d.finish();},/UTF-8|utf-8/);
assert.throws(()=>{const d=D.createDecoder();d.push(Buffer.from([0xff,0xfe,0x61,0]));d.push(Buffer.from([0x62]));d.finish();},/utf-16le/);
assert.throws(()=>D.create().push('void sub_100() {\0}'),/NUL/);
assert.throws(()=>{const p=D.create();p.push('// RVA: 0x1000\npublic class Test {}');p.finish();},/dump.cs/);
assert.throws(()=>{const p=D.create();p.push('void sub_100(){\nputs("unfinished');p.finish();},/dòng 2.*sub_100/);
assert.equal(E.textEvidence('CheckHook','test')[0].group,'hook');
assert(E.textEvidence('VerifyCodeSignature','test').some(e=>e.group==='signature'));
assert(E.textEvidence('CheckEmulator','test').some(e=>e.group==='environment'));
assert.equal(E.textEvidence('ordinary hook callback','test').length,0);
assert.equal(E.callEvidence('SHA256')[0].kind,'generic-api');
// Exercise the actual WKWebView adapter and preserve the previous workspace on failure.
const elements=new Map();function el(id){if(!elements.has(id))elements.set(id,{disabled:false,value:'',textContent:'',addEventListener(){}});return elements.get(id);}
const context={OffsetEvidence:E,OffsetDumpStream:D,TextDecoder,Uint8Array,atob,console,
 document:{getElementById:el,querySelectorAll(){return [];}},webkit:{messageHandlers:{iosDesk:{postMessage(){}}}},
 rows:[],dumpRows:[{name:'previous'}],dumpName:'previous.c',model:null,selected:null,demoMode:false,
 report(){},setDumpBusy(){},setAnalysisBusy(){},rebuild(){context.rows=context.dumpRows;}};
context.window=context;vm.createContext(context);vm.runInContext(fs.readFileSync(require.resolve('../App/Web/ios-bridge.js'),'utf8'),context);
const bridge=context.OffsetIOS,bytes=encoded('utf-16be');bridge.setImportBusy(true);bridge.begin('dump','test.c',bytes.length);
for(let i=0;i<bytes.length;i+=3)bridge.append(bytes.subarray(i,i+3).toString('base64'));
bridge.finish();assert.equal(context.dumpRows.length,2);assert.equal(context.dumpImportStats.encoding,'utf-16be');assert.equal(context.DeskBusy,false);
const previous=context.dumpRows;bridge.setImportBusy(true);bridge.begin('dump','bad.c',4);
assert.throws(()=>bridge.append(Buffer.from([0xff,0xff,0xff,0xff]).toString('base64')),/không hợp lệ/);
bridge.cancel('failed');assert.strictEqual(context.dumpRows,previous);assert.equal(context.DeskBusy,false);
bridge.begin('dump','short.c',8);bridge.append(Buffer.from('abcd').toString('base64'));assert.throws(()=>bridge.finish(),/chưa đầy đủ/);bridge.cancel();
console.log('PASS v7 encoding/chunk boundaries, malformed files, named checks, C# diagnostic, iOS bridge import, busy recovery and workspace preservation.');
